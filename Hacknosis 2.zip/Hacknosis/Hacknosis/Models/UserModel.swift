//
//  UserModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 13/10/23.
//

import Foundation
import RealmSwift
/**
 Used to store the user information
 */
final class UserModel:Object, Decodable {
    
    //MARK: - Persisted variables
    //@Persisted(primaryKey: true) var id:String
    @Persisted var firstName:String?
    @Persisted var lastName:String?
   // @Persisted var name:String
//    @Persisted var initials:String
//    @Persisted var title:String?
   // @Persisted var roles:[String]? = []
    @Persisted var email:String?
    @Persisted var isCurrentUser:Bool = false
    @Persisted var tenantUserId:String?
    @Persisted var subscriptionUserId:String
//    @Persisted var subscriptionNamespacePrefix:String?
    
    enum CodingKeys: String, CodingKey {
       // case id
        case firstName = "first_name"
        case lastName = "last_name"
//        case name
//        case initials
//        case title
//        case role = "role_name"
       // case roles
        case email
        case tenantUserId = "tenant_user_id"
        case subscriptionUserId = "subscription_user_id"
//        case subscriptionNamespacePrefix
    }
}
