//
//  NodeCollectionModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import Foundation

struct NodeCollectionModel:Decodable {
    
    //MARK: - Inner objects
    struct Page:Decodable {
        var sort:String
        var size:Int
        var totalElements:Int
        var totalPages:Int
        var number:Int
    }
    
    struct Embedded:Decodable {
        var collection:[NodeModel]
    }
    
    //MARK: - Variables
    var embedded:Embedded?
    var page:Int?
    
    enum CodingKeys: String, CodingKey {
        case embedded = "_embedded"
        case page = "page"
    }
    
}
