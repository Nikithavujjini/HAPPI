//
//  ShareLinkResponseModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 25/10/23.
//

import Foundation

class ShareResponseModel: Decodable {
    var link_uri: String?
}
