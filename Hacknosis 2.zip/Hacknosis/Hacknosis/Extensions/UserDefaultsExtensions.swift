//
//  UserDefaultsExtensions.swift
//  Core Content
//
//  Created by Jamie Klapwyk on 2021-08-12.
//

import Foundation

public extension UserDefaults {

    class var appGroup: UserDefaults? {
        return UserDefaults(suiteName: AppGroup)
    }
}
