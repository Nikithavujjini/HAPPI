//
//  Images.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 16/10/23.
//

import Foundation

let UPLOAD_ICON: String = "upload-icon";
let VIEW_ICON: String = "view-icon";
let LOGO: String = "logo";
 let ASSET_IMAGE_FILE_TYPE_IMAGE:String = "mime-image"


public let ASSET_IMAGE_BACKGROUND_GRADIENT:String = "background-gradient"
public let ASSET_IMAGE_CORE_CONTENT_BRAND:String = "core-content-brand"
public let ASSET_IMAGE_CORE_CONTENT_BRAND_LOGO:String = "core-content-brand-logo"
public let ASSET_IMAGE_CORE_CONTENT_BRAND_VERTICAL:String = "core-content-brand-vertical"
public let ASSET_IMAGE_ROOT_DEVICE_ICON:String = "root-device-icon"

//Shortcuts
public let ASSET_IMAGE_SHORTCUT_ITEM_SHADOW_COLOR:String = "shortcut-item-shadow-color"
public let ASSET_IMAGE_INFO_ICON: String = "info-icon"
public let ASSET_IMAGE_SEPERATOR_BACKGROUND = "seperator-background"

//File type
public let ASSET_IMAGE_FILE_TYPE_AUDIO:String = "mime-audio"
public let ASSET_IMAGE_FILE_TYPE_DOCUMENT:String = "mime-document"
public let ASSET_IMAGE_FILE_TYPE_EXCEL:String = "mime-excel"
public let ASSET_IMAGE_FILE_TYPE_FOLDER:String = "mime-folder"
public let ASSET_IMAGE_FILE_TYPE_EMPTY_FOLDER:String = "mime-empty-folder"

public let ASSET_IMAGE_FILE_TYPE_FORMULA:String = "mime-formula"
public let ASSET_IMAGE_FILE_TYPE_HTML:String = "mime-html"
public let ASSET_IMAGE_FILE_TYPE_MAIL:String = "mime-mail"
public let ASSET_IMAGE_FILE_TYPE_PAPER:String = "mime-paper"
public let ASSET_IMAGE_FILE_TYPE_PDF:String = "mime-pdf"
public let ASSET_IMAGE_FILE_TYPE_GOOGLE_DOC:String = "mime-google-doc"
public let ASSET_IMAGE_FILE_TYPE_GOOGLE_SHEET:String = "mime-google-sheet"
public let ASSET_IMAGE_FILE_TYPE_GOOGLE_SLIDE:String = "mime-google-slide"

public let ASSET_IMAGE_FILE_TYPE_POWERPOINT:String = "mime-powerpoint"
public let ASSET_IMAGE_FILE_TYPE_PROJECT:String = "mime-project"
public let ASSET_IMAGE_FILE_TYPE_PRESENTATION:String = "mime-presentation"
public let ASSET_IMAGE_FILE_TYPE_SPREADSHEET:String = "mime-spreadsheet"
public let ASSET_IMAGE_FILE_TYPE_URL:String = "mime-url"
public let ASSET_IMAGE_FILE_TYPE_VIDEO:String = "mime-video"
public let ASSET_IMAGE_FILE_TYPE_VISIO:String = "mime-visio"
public let ASSET_IMAGE_FILE_TYPE_WORD:String = "mime-word"
public let ASSET_IMAGE_FILE_TYPE_WORKSPACE:String = "mime-workspace"
public let ASSET_IMAGE_FILE_TYPE_XML:String = "mime-xml"
public let ASSET_IMAGE_FILE_TYPE_ZIP:String = "mime-zip"
public let ASSET_IMAGE_EMPTY_LIST:String = "empty-list"
public let ASSET_IMAGE_FILE_CORRUPT:String = "error-file-currupt"
public let ASSET_IMAGE_SERVER_ERROR:String = "error-file-server"
public let ASSET_IMAGE_FILE_OFFLINE:String = "item_offline"
public let ASSET_IMAGE_EMPTY_LIST_CONTENT:String = "empty-list-content"
//Tab
public let ASSET_IMAGE_SHORTCUT_FOLDER:String = "shortcut-folder"
public let ASSET_IMAGE_SHORTCUT_FOLDER_INNER:String = "shortcut-folder-inner"
public let ASSET_IMAGE_SHORTCUT_FILE:String = "shortcut-file"
public let ASSET_IMAGE_SHORTCUT_WEBLINK:String = "shortcut-weblink"

//Tab
public let ASSET_IMAGE_TAB_HOME:String = "tab-home"
public let ASSET_IMAGE_TAB_PROFILE:String = "tab-profile"
public let ASSET_IMAGE_TAB_FAVORITES:String = "tab-favorites"
public let ASSET_IMAGE_TAB_OFFLINE:String = "tab-offline"
public let ASSET_IMAGE_ERROR_CIRCLE:String = "error-circle"


//Common
public let ASSET_IMAGE_CHECKMARK:String = "checkmark"
public let ASSET_IMAGE_CHECKMARK_WHITE:String = "checkmark-white"

//System images used
public let SYSTEM_IMAGE_ARROW_DOWN:String = "arrow.down"
public let SYSTEM_IMAGE_ARROW_UP:String = "arrow.up"
public let SYSTEM_IMAGE_CHEVRON_DOWN:String = "chevron.down"
public let SYSTEM_IMAGE_ARROW_FORWARD:String = "chevron.forward"
public let SYSTEM_IMAGE_ARROW_BACKWARD:String = "chevron.left"
public let SYSTEM_IMAGE_LOCK_FILL:String = "lock.fill"
public let SYSTEM_IMAGE_CHECKMARK:String = "checkmark"
public let SYSTEM_IMAGE_MAGNIFYING_GLASS:String = "magnifyingglass"
public let SYSTEM_IMAGE_XMARK_CIRCLE_FILL:String = "xmark.circle.fill"
public let SYSTEM_IMAGE_EDIT:String = "pencil"
public let SYSTEM_IMAGE_CALENDER: String = "calendar"

public let SYSTEM_IMAGE_STAR:String = "star"
public let SYSTEM_IMAGE_STAR_FILLED:String = "star.fill"
public let SYSTEM_IMAGE_LOCK_PHONE:String = "lock.iphone"
public let SYSTEM_IMAGE_ELLIPSIS:String = "ellipsis"
public let SYSTEM_IMAGE_STAR_SQUARE_FILL:String = "star.square.fill"
public let SYSTEM_IMAGE_CHECKMARK_FILL:String = "checkmark.circle"
public let SYSTEM_IMAGE_CHECKMARK_EMPTY:String = "circle"
public let SYSTEM_IMAGE_CHEVRON_UP:String = "chevron.up"
public let SYSTEM_IMAGE_XMARK:String = "xmark"

//Favorites
public let FAVORITES_TAB_ARROW_UP:String = "fav-upward-arrow"
public let FAVORITES_IMAGE_STAR:String = "fav-star"
public let FAVORITES_ACCESSORY_RIGHT:String = "fav-accessory-right"
public let FAVORITES_LIST_EMPTY:String = "fav-list-empty"
public let FAVORITES_GROUP_EMPTY:String = "fav-group-empty"

//Swipe
public let SWIPE_FAVORITE_EMPTY:String = "swipe-fav-empty"
public let SWIPE_FAVORITE_FILL:String = "swipe-fav-fill"
public let SWIPE_MORE:String = "swipe-more"
public let SWIPE_MORE_SELECTED:String = "swipe-more-selected"
public let ACTION_SHEET_SELECT:String = "action_select"
public let SWIPE_REMOVE_OFFLINE:String = "toolbar_remove_offline"
public let SWIPE_MARK_OFFLINE:String = "toolbar_mark_offline"
public let SWIPE_RENAME:String = "swipe-rename"
public let SWIPE_PROPERTIES:String = "swipe-properties"
public let SWIPE_DOWNLOAD:String = "swipe_download"

public let HEADER_ACTIONS_MORE:String = "header-actions-more"
public let HEADER_ACTIONS_MORE_SELECTED:String = "header-actions-more-selected"


//Action sheet
public let ACTION_SHEET_MARK_OFFLINE:String = "mark-offline"
public let ACTION_SHEET_GO_TO_LOCATION:String = "goto_location"
public let ACTION_SHEET_RENAME:String = "action_rename"
public let FILES_LIST_CLOSE:String = "files-list-close"
public let ACTION_SHEET_FOLDER:String = "action_folder"
public let ACTION_SHEET_DOC:String = "action_doc"
public let ACTION_SHEET_PHOTO:String = "action_add_photo"
public let ACTION_SHEET_VERSION:String = "action_add_version"
public let ACTION_SHEET_PROPERTIES:String = "action_properties"
public let ACTION_SHEET_DOWNLOAD: String = "action_download"
public let ACTION_SHEET_SCAN: String = "action_scan_document"


public let LOGIN_MENU_TRANSPARENT_IMAGE:String = "transparentImage"
public let ACTION_CALENDER:String = "action_calendar"


//Offline
public let OFFLINE_QUESTION_ICON:String = "question-icon"
public let PIN_FILL:String = "pin-fill"
public let PIN_EMPTY:String = "pin-empty"
public let PIN_VERIFIED:String = "pin-verified"
public let OVERLAY_ERROR:String = "overlay_error"
public let OVERLAY_SUCCESS:String = "overlay_success"
public let OVERLAY_WARNING:String = "overlay_warning"
public let ACTION_SHEET_REMOVE_OFFLINE:String = "action_sheet_remove_offline"

public let IMAGE_MESSAGES_CLOSE:String = "messages_close"
public let IMAGE_MESSAGES_RETRY:String = "messages_retry"
public let IMAGE_MESSAGES_DONE:String = "messages_item_done"


public let IMAGE_SEARCH_ICON:String = "search_icon"
public let IMAGE_ADVANCED_SEARCH_ICON:String = "advanced-search"
public let IMAGE_SEARCH_CLEAR:String = "search_clear"
public let IMAGE_SEARCH_CLEAR_USER_ADVANCEDSEARCH:String = "input_cancel_user_advancedsearch"
public let IMAGE_USERS_SEARCH_CLEAR:String = "users_search_clear"

public let IMAGE_EMPTY_SEARCH_RESULTS:String = "empty_search_results"

public let PIN_INCORRECT:String = "pin-incorrect"
public let CHECKMARK_GREEN:String = "check_mark_green"
public let OFFLINE_OVERLAY_WARNING:String = "offline_overlay_warning"
public let LOCK_ICON:String = "lock-icon"
public let LOCK_PIN_FILL:String = "lock-pin-fill"
public let LOCK_PIN_EMPTY:String = "lock-pin-empty"
public let LOCK_BACK:String = "locked-back"

//Security
public let SECURITY_CHECKMARK:String = "security-checkmark"
public let SECURITY_EMPTY_CIRCLE:String = "empty-circle"
public let OFFLINE_DELETE:String = "delete"
public let FILE_UPLOAD:String = "upload"
public let OFFLINE_RETRY:String = "retry"
public let ALPHABET_ERROR_ICON:String = "alphabet-error-icon"

//Properties
public let DISCLOSURE_ARROW_IMAGE:String = "disclosure-arrow"
public let PROPERTIES_EDIT_IMAGE:String = "properties_edit"
public let PROPERTIES_DROP_DOWN_ARROW:String = "drop_down_arrow"
public let LIST_CHECK_MARK_IMAGE:String = "list_check_image"
public let APPLY_TO_ALL_ICON:String = "apply_to_all_icon"
public let COPIED_FIELD_ICON:String = "copied_field_icon"
public let CLOSE_X_ICON:String = "close_x_icon"
public let PROPERTIES_FOLDER_PICKER_ICON:String = "folder_picker_icon"



public let IMAGE_BANNER_ERROR:String = "banner_error_icon"

public let KEYBOARD_DELETE:String = "keyboard-delete"

//My Tasks
public let ASSET_IMAGE_SHORTCUT_TASK:String = "shortcut-task"
public let MY_TASK_LIST_MIME_ICON:String = "mytask-mime-icon"
public let MY_TASK_LIST_GROUP_ICON:String = "mytask-group-icon"
public let MY_TASK_STATUS_RUNNING_ASSET:String = "status-running"

//Copy/Move
public let IMAGE_ADD_FOLDER_DARK:String = "add-folder-dark"
public let IMAGE_ADD_FOLDER_LIGHT:String = "add-folder-light"
public let ACTION_SHEET_COPY: String = "action_copy"
public let ACTION_SHEET_MOVE: String = "action_move"
public let COPYMOVE_CURRENT_LOCATION_ICON: String =  "action_current_location"
public let COPYMOVE_ENTERPRISE_ICON: String =  "action_enterprise"
public let COPYMOVE_FAVORITE_ICON: String =  "action_favorite"
public let COPYMOVE_FOLDER_ICON: String =  "action_Copy_folder"
public let SWIPE_ACTION_APPROVE:String = "action_approve"

public let SWIPE_ACTION_REJECT:String = "action_reject"
public let SWIPE_ACTION_CLAIM:String = "action_claim"
public let SWIPE_ACTION_REASSIGN:String = "action_reassign"
public let EMPTY_TASKS_LIST:String = "empty-tasks-list"
public let BOTTOMBAR_COPY: String = "swipe_copy"
public let BOTTOMBAR_MOVE: String = "swipe_move"
public let BOTTOMBAR_ADDVERSION: String = "swipe_add_version"
public let ADVANCED_SEARCH_ADD: String = "advanced-search-add"
public let GO_TO_LOCATION_ICON: String = "action_goto_location"
public let ASSET_IMAGE_ADD_SCAN_ICON: String = "add-scan-icon"
public let ASSET_IMAGE_CROP_SCAN_ICON: String = "crop-icon"
public let ASSET_IMAGE_FILTER_SCAN_ICON: String = "filters-icon"
public let ASSET_IMAGE_DELETE_SCAN_ICON: String = "trash-icon"
public let ASSET_IMAGE_ROTATE_SCAN_ICON: String = "rotate-scan-icon"
public let ASSET_IMAGE_REORDER_ICON: String = "reorder-icon"
public let ASSET_FACET_FILTER_ICON: String = "facet_filter"
public let ASSET_FACET_FILTER_SELECTED_ICON: String = "facet_filter_selected"
public let SEND_SIGNATURE: String = "send_signature"
public let CANCEL_SIGNATURE: String = "cancel_signature"
public let SIGNATURE_STATUS: String = "status_signature"
public let SIGNATURE_EMAIL_SENT: String = "email_sent"
public let CANCEL_SIGNATURE_BOTTOM_BAR: String = "cancel_signature_bottom_bar"
public let SIGNATURE_CANCELLED_IMAGE: String = "signature_cancelled"
public let SIGNATURE_PENDING_IMAGE: String = "signature_pending"
public let SIGNATURE_SENT_IMAGE: String = "signature_sent"
public let SIGNATURE_DECLINED_IMAGE: String = "signature_declined"
