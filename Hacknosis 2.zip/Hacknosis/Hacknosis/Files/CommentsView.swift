//
//  CommentsView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 25/10/23.
//

import SwiftUI

struct CommentsView: View {
    
    @State private var profileText = ""
    @StateObject var viewModel: CommentsViewModel = CommentsViewModel()
    @Environment(\.presentationMode) var presentationMode

    var node:NodeModel? = nil

    var body: some View {
        VStack(spacing: 20) {
            TextEditor(text: $profileText)
                           .foregroundStyle(.secondary)
                           .padding(.horizontal)
                           .frame(height: 80)
                           .navigationTitle("Add comments")
            
            
            Button {
                viewModel.addComment(nodeId: node?.fileId ?? "" , comment: profileText) { node, error in
                    if error == nil {
                        DispatchQueue.main.asyncAfter(deadline: .now()) {
                            self.presentationMode.wrappedValue.dismiss()
                        }
                    }
                }
                print("make API call")
                //add action
            } label: {
                HStack(spacing: 0) {
                    Spacer()
                    Text("Submit")
                    Spacer()
                }
            }
            
            Spacer()
        }
        .background(Color.blue.opacity(0.1))
    }
}
