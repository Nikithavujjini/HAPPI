//
//  FilesViewModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import UIKit
import Combine
import SwiftUI
import UniformTypeIdentifiers
import AVFoundation

class FilesViewModel:AbstractViewModel, ObservableObject  {
    
    var selectedNodeForUpload: NodeModel? = nil
    @ObservedObject var selectedMediaItems = PickedMediaItems()
    @Published var isShowingFilesScreenView: Bool = false
    @Published var isShowingViewer:Bool = false
    @Published var isShowingCommentView:Bool = false
    
    @Published var nodes:[NodeModel] = []
    @Published var uploadingNodes:[NodeModel] = [NodeModel]()
    var nodeId: String = "bf415310-f76b-4c8b-a617-b6f21eebe18c"
    var taskRequests:Set<Task> = Set<Task<Void, Never>>()
    var nodeToViewer:NodeModel? = nil
    
    @Published var totalNodesCount:Int = 0
    @Published var ongoingUploads: [String : CoreUploadObject] = [:]
    @Published var parentNode:NodeModel? = nil
    var requests:Set<AnyCancellable> = Set<AnyCancellable>()
    var fileService: FilesService
    override init() {
        self.fileService = FilesService()
    }
    
    func onViewAppear() {
        Task { [weak self] in
            await self?.getReports()
        }
    }
    func getReports() async {
        // guard let nodeId = nodeId else { return }
        
        Task {
            do {
                let nodeCollection = try await fileService.getReports(rootId: nodeId)?.async()
                
                if let nodeCollection = nodeCollection, (nodeCollection.page ?? 0) > 0 {
                    if let embedded = nodeCollection.embedded, embedded.collection.count > 0 {
                        var nodes = self.nodes
                        nodes.append(contentsOf: embedded.collection)
                        self.nodes = nodes.removeDuplicates()
                    }
                }
            }
            catch let error as CoreError {
                print(error.message)
            }
        }
        
    }
    
    func uploadSelectedFiles(_ fileAttributes:[UploadFileAttributesModel] = [])  {
        //update selected files with the properties
        if fileAttributes.count > 0 {
            for (index, item) in selectedMediaItems.items.enumerated() {
                if index < fileAttributes.count {
                    var fileItem =  item
                    fileItem.updateFileAttributes(fileAttributes[index])
                    selectedMediaItems.items[index] = fileItem
                }
            }
        }
        
        for item in selectedMediaItems.items {
            if let mediaUrl = item.url {
                let mimeType = mediaUrl.mimeType()
                let mediaName = mediaUrl.lastPathComponent
                
                let nodeModel = NodeModel()
                nodeModel.name = item.fileAttributes?.fileName ?? mediaName
                nodeModel.mimeType = mimeType
                var parentId = "bf415310-f76b-4c8b-a617-b6f21eebe18c"
                
                let caseNodeId:String? = nil
               // var fileAttribute = item.fileAttributes
                
                if !uploadingNodes.contains(where: {$0.fileUniqueKey == nodeModel.fileUniqueKey}) {
                    uploadingNodes.insert(nodeModel, at: 0)
                }

                self.isShowingEmptyList = false
                
                let img = item.image
                let base64 = img?.base64
                
                //call google api
                if let base64 {
                    CoreUploadManager.shared.uploadFileToGcp(bytesData: base64)
                }
                let fileKey =  parentId + mediaName
                self.uploadFile(parentId:parentId, fileUrl: mediaUrl, fileName: mediaName, mimeType: mimeType, fileKey: fileKey, mimeTypeImageName: nodeModel.imageName, caseNodeId: caseNodeId)
                
            }
        }
       
    }
    
    
    func uploadFile(parentId:String, fileUrl: URL, fileName: String, mimeType:String, fileKey:String, mimeTypeImageName:String, uploadFileAttributes:UploadFileAttributesModel? = nil, caseNodeId:String? = nil) {
        var fileSize = 10 // kept some value in case of unable to read from resource, dont want to fail by default
        if  let resources = try? fileUrl.resourceValues(forKeys:[.fileSizeKey]), let size = resources.fileSize {
            fileSize = size
        }
        
        let multipart = MultipartFormDataUploadHelper()
        multipart.buildMultipartFormDataUploadFile(sourceFileUrl: fileUrl, fileName: fileName, contentType: mimeType) {[weak self] url in
            DispatchQueue.main.async {
                guard let self = self else {
                    //remove temarary multipart file
                    CoreFileUtils.removeFile(at: fileUrl)
                    CoreFileUtils.removeFile(at: url)
                    return
                }
                if let url = url {
                    let documentDetails = UploadDocumentDetails(name: fileName, mimeType: mimeType, parentId: parentId, fileKey: fileKey, fileUrl: url, fileSize: fileSize, mimeTypeImageName: mimeTypeImageName, caseNodeId: caseNodeId, uploadFileAttributes: uploadFileAttributes, uploadType: .newUpload, ownerID: self.selectedNode?.ownerID(), fileID: self.selectedNode?.fileId, versionName: self.selectedNode?.name, boundary: multipart.BOUNDARY, type: self.selectedNode?.fileType ?? "cms_file")
                    self.uploadFile(for: documentDetails)
                }
            }
            
        }
    }
    
    func uploadFile(for documentDetails: UploadDocumentDetails) {
        CoreUploadManager.shared.uploadFile(fileData: documentDetails, service: FilesService()) { [weak self] fileKey in
            DispatchQueue.main.async {
                self?.ongoingUploads = CoreUploadManager.shared.currentUploads()
            }
        } onProgress: { [weak self] progress, fileKey in
            DispatchQueue.main.async {
                self?.ongoingUploads = CoreUploadManager.shared.currentUploads()
            }
        } onCompletion: { [weak self, documentDetails] node, fileKey, error in
            DispatchQueue.main.async {
                //                self?.updateSharedLinkVersion(node,error)
                //If upload success(node != nil) or some thing wrong with multiple file uploads (node == nil && error == nil),
                if node != nil || (node == nil && error == nil) {
                    CoreUploadManager.shared.removeFromUploads(forUniqueKey: fileKey)
                    self?.uploadingNodes.removeAll(where: { node in
                        node.fileUniqueKey == fileKey
                    })
                    // self?.listItemContentId = UUID().uuidString
                }
                
                if let node = node, let self = self {
                    if documentDetails.uploadType == .addVersion {
                        for (index, eachnode) in self.nodes.enumerated() where eachnode.fileId == documentDetails.fileID ?? EMPTY_STRING {
                            self.insert(node: node, at: index)
                            self.objectWillChange.send()
                            break
                        }
                    } else if self.parentNode?.fileId == documentDetails.parentId {
                        if !self.nodes.contains(where: {$0.fileId == node.fileId}) {
                            self.nodes.insert(node, at: 0)
                            self.totalNodesCount = self.nodes.count
                        }
                        
                    }
                    //                    self.highlightedNodeIds.append(node.id)
                    //                    self.justNowUploadedNodeIds.append(node.id)
                    //fetch node actions for downloaded file
                    //                    Task {
                    //                        let nodeActions = await self.getNodesActionsNew(nodeIds: [node.id])
                    //                        for nodeAction in nodeActions?.embedded.collection ?? [] {
                    //                            if var node = self.nodes.filter({ $0.fileId == nodeAction.id }).last {
                    //                                node.nodeActions = nodeAction.actions
                    //                            }
                    //                        }
                    //                    }
                }
                self?.ongoingUploads = CoreUploadManager.shared.currentUploads()
                if self?.nodes.count ?? 0 > 0 || self?.uploadingNodes.count ?? 0 > 0  {
                    self?.isShowingEmptyList = false
                } else {
                    self?.isShowingEmptyList = true
                }
                self?.objectWillChange.send()
            }
        }
    }
    
    private func insert(node: NodeModel,at index:Int) {
        self.nodes[index] = node
    }
    
    func showViewer(node:NodeModel) {
        nodeToViewer = node
        isShowingViewer = true
    }
    
    func getShareLink(nodeId: String) {
        Task {
            do {
                let shareLinkResponse = try await fileService.getShareLink(nodeId: nodeId)?.async()
            } catch let error  {
                if let error = error as? CoreError {
                    print(error.message)
                }
            }
        }
    }
    
}
