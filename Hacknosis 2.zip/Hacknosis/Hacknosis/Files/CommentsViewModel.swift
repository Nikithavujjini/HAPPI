//
//  CommentsViewModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 25/10/23.
//



import Foundation
import Combine

class CommentsViewModel:AbstractViewModel, ObservableObject  {
    var requests:Set<AnyCancellable> = Set<AnyCancellable>()

    func addComment(nodeId:String, comment:String, completion:@escaping(_ node:NodeModel?, _ error:CoreError?) -> Void)  {
        let request = FilesService().addComment(nodeId: nodeId, comment: comment) { node, error in
          completion(node, error)
        }
        if let request = request {
            self.requests.insert(request)
        }
    }
}

