//
//  FilesListItemView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import SwiftUI

struct FilesListItemView: View {
    var node: NodeModel
    init(node: NodeModel) {
        self.node = node
    }
    var body: some View {
        ZStack {
            HStack(spacing: 12) {
                Image(ASSET_IMAGE_FILE_TYPE_IMAGE)
                Text(node.name)
                    .font(.title3)
                Spacer()
            }
            .padding(EdgeInsets(top: 16, leading: 16, bottom: 16, trailing: 16))
            .contentShape(Rectangle())
            .background(Color.blue.opacity(0.1))
        }
       // Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct FilesListItemView_Previews: PreviewProvider {
    static var previews: some View {
        FilesListItemView(node: NodeModel(id: "", name: "File_129382", mimeType: "application/octet-stream", contentSize: 0))
    }
}
