//
//  ProfileScreenView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 25/10/23.
//

import SwiftUI

struct ProfileScreenView: View {
    @StateObject var viewModel: ProfileViewModel = ProfileViewModel()
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                if let user = viewModel.user {
                    Text(user.firstName ?? "")
                    Text(user.lastName ?? "")
                    Text(user.email ?? "")
                }
            }
        }
        .onAppear {
            viewModel.onViewAppear()
        }
    }
    
    
}

struct ProfileScreenView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileScreenView()
    }
}
