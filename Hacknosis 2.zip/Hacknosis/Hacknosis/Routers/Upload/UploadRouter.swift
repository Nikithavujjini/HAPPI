//
//  UploadRouter.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import Foundation


enum UploadRouterType {
    ///Get node based on node id
    //case getReportsList(rootId:String)
    case uploadFileToCss(filePath: String)
    

}

/**
 Used for node routes.
 */
class UploadFilesRouter:CoreAbstractRouter {
    var routerType:UploadRouterType
  //  private var sharedLink: LinkShareModel?

    ///This part of the url should just include the host.
    override var hostUrl:URL? {
//        if let sharedLink {
//            return sharedLink.currentEnvironmentUrl
//        }
        guard let hostUrl = EnvironmentManager.shared.cmsUrl else { return nil }
        return hostUrl
    }
    
    override var hostWithPathUrl: URL? {
        guard var apiUrl = hostUrl else { return nil }
        switch routerType {
        case .uploadFileToCss:
            apiUrl.appendPathComponent("v2/content")
            return apiUrl

      //  https://cms-c4sapqe.qe.bp-paas.otxlab.net/instances/folder/cms_folder/{{root_id}}/items
      
     
        }
    }
    
    override var contentType: HTTPContentType {
        switch routerType {

        case .uploadFileToCss:
            return .multipart

        default: return .any
        }
    }
    override var httpMethod: HTTPMethod {
        switch routerType {
        case .uploadFileToCss:
            return .post
        }
    }
    

    
    override var httpBody: Data? {
        switch routerType {
            
        case .uploadFileToCss(let filePath) :
            var json: [String: Any] = ["name" : filePath]
            
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            return jsonData
        }
    }
    
    override var queryParameters: HTTPParameters {
        switch routerType {
        
        case .uploadFileToCss(let filePath):
//            if sharedLink != nil {
//                return ["include-children-total" : "false"]
//            } else {
                return ["name" : filePath]
           // }
            
        }
    }
    
//    init(routerType:NodeRouterType){
//        self.routerType = routerType
//        super.init()
//    }
    
    init(routerType:UploadRouterType){
       // self.sharedLink = sharedLink
        self.routerType = routerType
        super.init()
    }
    
    override var acceptContentType: HTTPContentType? {
        switch routerType {
        case .uploadFileToCss :
            return .halJson
        }
    }
        
}


