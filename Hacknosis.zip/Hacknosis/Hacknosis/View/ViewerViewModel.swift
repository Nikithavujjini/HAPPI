//
//  ViewerViewModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import Foundation

enum DocumentScreenType {
    case documentSaver
    case documentViewer
}

class ViewerViewModel:ObservableObject {
    var documentType: DocumentScreenType = .documentViewer
    @Published var isLoading: Bool = false
    @Published var downloadPercentage: Float = 0
    @Published var showErrorMessage: Bool = false
    @Published var showFileNotFoundError: Bool = false
    @Published var documentDownloadedUrl: URL?
    @Published var showDocumentSave:Bool = false
    var fileItemData:NodeModel?
    var updatedTime:String = EMPTY_STRING
    init(fileItemData:NodeModel?) {
        self.fileItemData = fileItemData
      //  self.updatedTime = updatedTime
    }
    
    func onViewAppear() {
        fetchDocumentDetails()
    }
    func showFileDoesNotExistError() {
        showErrorMessage = true
    }
    
    func fetchDocumentDetails() {

        //show error if file don't exist
        guard let fileItemData = fileItemData,
              let documentLink = fileItemData.originalFileUrl
        else {
            showFileDoesNotExistError()
            return
        }

        let nodeId = fileItemData.id
        let fileName = fileItemData.name





        isLoading = true
        var fileStoragePath = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        fileStoragePath = fileStoragePath.appendingPathComponent("\(nodeId)__\(updatedTime)")
        let fileUrl = getFileStoragePathURL(nodeId: "\(nodeId)__\(updatedTime)", fileName: "\(fileName)", updateTime: updatedTime)
        //show already downloaded file if already exist
        if FileManager.default.fileExists(atPath: fileUrl.path) {
            self.documentDownloadedUrl = fileUrl
            showDocumentSave = documentType == .documentSaver
            return
        }

        CoreDownloadManager.shared.downloadFile(fileData: fileItemData, isViewer: true,nodeService: FilesService(),  onProgress: { progress, fileKey in
            self.downloadPercentage = min(Float(progress), 1)
        }) { [weak self] downloadedUrl, fileKey, error in
            if error != nil {
                self?.showErrorMessage = true
            } else {
                do {
                    if let downloadedUrl {

                        //create a directory with node node name if it doesn't exist
                        try? FileManager.default.createDirectory(at: fileStoragePath, withIntermediateDirectories: false, attributes: nil)

                        //first remove the file if already exist
                        if FileManager.default.fileExists(atPath: fileUrl.path) {
                            try FileManager.default.removeItem(at: fileUrl)
                        }

                        //move the item to destination path
                        try FileManager.default.moveItem(atPath: downloadedUrl, toPath: fileUrl.path)
                                                
                        self?.showDocument(fileUrl:fileUrl)
                        
                    } else {
                        self?.showErrorMessage = true
                    }
                }
                catch {
                    self?.showErrorMessage = true
                }
            }
        }
    }

    func getFileStoragePathURL(nodeId:String, fileName:String, updateTime:String) -> URL {
        var fileStoragePath = cacheDirectoryUrl()
        fileStoragePath = fileStoragePath.appendingPathComponent(nodeId)
        return fileStoragePath.appendingPathComponent(fileName)
    }
    
    func cacheDirectoryUrl() -> URL {
        return FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
    }
    
    func showDocument(fileUrl:URL){
        documentDownloadedUrl = fileUrl
        isLoading = false
        showDocumentSave = documentType == .documentSaver
    }
}
