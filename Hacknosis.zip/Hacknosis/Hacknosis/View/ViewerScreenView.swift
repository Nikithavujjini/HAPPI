//
//  ViewerScreenView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import SwiftUI

struct ViewerScreenView: View {
    @StateObject var viewModel:ViewerViewModel
    var node:NodeModel?
    var updatedTime:String?
    init(node:NodeModel? = nil, updatedTime:String?) {
        self.updatedTime = updatedTime
        self.node = node
        _viewModel = StateObject(wrappedValue:  ViewerViewModel(fileItemData: node))
    }
    
    var body: some View {
        ZStack {
            if let fileUrl = viewModel.documentDownloadedUrl, viewModel.documentType == .documentViewer {
                PreviewController(nodeName: node?.name ?? EMPTY_STRING, nodeId: node?.id ?? EMPTY_STRING, documentLink: fileUrl, mimeType: node?.mimeType)
                    .ignoresSafeArea()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(false)
       // .navigationBarItems(leading: viewModel.sharedLink == nil  ? nil : backButton())
        .background(Color(COLOR_VIEWER_BACKGROUND))
        .navigationTitle(node?.name ?? EMPTY_STRING)
        .onAppear {
            viewModel.onViewAppear()
        }
    }
}


//struct ViewerScreenView_Previews: PreviewProvider {
//    static var previews: some View {
//        ViewerScreenView()
//    }
//}


