//
//  HomeScreenView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 13/10/23.
//

import SwiftUI

class Reports:  Hashable {
    static func < (lhs: Reports, rhs: Reports) -> Bool {
        return lhs == rhs
    }
    
    static func == (lhs: Reports, rhs: Reports) -> Bool {
        return lhs.title == rhs.title
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(title)
    }
    
    var title: String
    var image: String
    var screenType: ScreenType
    init(title: String, image: String, screenType: ScreenType) {
        self.title = title
        self.image = image
        self.screenType = screenType
    }
}
enum ScreenType {
    case upload
    case view
}
struct HomeScreenView: View {
    @StateObject var viewModel: HomeViewModel = HomeViewModel()
    
    let adaptiveColumns = [
        GridItem(.adaptive(minimum: 170))
    ]
    var data:[Reports] = [Reports(title: "Upload reports", image: UPLOAD_ICON, screenType: .upload), Reports(title: "View reports", image: VIEW_ICON, screenType: .view)]
    var body: some View {
        ZStack {
        
            Color.accentColor.edgesIgnoringSafeArea(.all)
            VStack {
                LazyVGrid(columns: adaptiveColumns,spacing:20) {
        
                    ForEach(data, id: \.self) { item in
                        ZStack {
                            VStack(alignment: .center) {
                                Image(item.image)
                                    .resizable()
                                    .aspectRatio( contentMode: .fit)
                                    .frame(width: 60,height: 60, alignment: .center)
        
                                Text("Upload reports")
                                    .opacity(0)
                                    .font(.title3)
                                Text(item.title)
                                    .font(.title3)
                            }
                            .onTapGesture {
                               // viewModel.onViewAppear()
                                if item.screenType == .upload {
                                    viewModel.isShowingUploadScreenView = true
                                } else {
                                    viewModel.isShowingFilesScreenView = true
                                }
                            }
                            .padding(EdgeInsets(.init(top: 24, leading: 16, bottom: 24, trailing: 16)))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16.0)
                                    .stroke(Color(GRID_ITEM_BORDER), lineWidth: 3.0))
                            .background(Color(GRID_ITEM_COLOR).cornerRadius(16))
                            .shadow(radius: 4)
                        }
                    }
                }
        
            }
            NavigationLink(EMPTY_STRING, destination: FilesScreenView(), isActive:$viewModel.isShowingFilesScreenView).opacity(0).isHidden(true)
            NavigationLink(EMPTY_STRING, destination: UploadFilesScreenView(), isActive:$viewModel.isShowingUploadScreenView).opacity(0).isHidden(true)
            NavigationLink(destination: EmptyView()) { EmptyView() }.opacity(0).isHidden(true)
        }
        //.navigationTitle()
    }
}

struct HomeScreenView_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreenView()
    }
}

