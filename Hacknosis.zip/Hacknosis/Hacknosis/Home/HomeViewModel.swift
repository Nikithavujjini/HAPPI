//
//  HomeViewModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import Foundation
class HomeViewModel:ObservableObject {
    var fileService: FilesService?
    var nodeId: String = "bf415310-f76b-4c8b-a617-b6f21eebe18c"
    var nodes: [NodeModel] = []
    @Published var isShowingFilesScreenView: Bool = false
    @Published var isShowingUploadScreenView: Bool = false
    init() {
        self.fileService = FilesService()
    }
    func onViewAppear() {
        Task { [weak self] in
            await self?.getReports()
        }
    }
    func getReports() async {
       // guard let nodeId = nodeId else { return }
        
        Task {
            // let nodeCollection = try await self.fileService.getReports(rootId: self.nodeId)
            do {
                let nodeCollection = try await fileService?.getReports(rootId: nodeId)?.async()
                
                if let nodeCollection = nodeCollection, (nodeCollection.page ?? 0) > 0 {
                    if let embedded = nodeCollection.embedded, embedded.collection.count > 0 {
                        var nodes = self.nodes
                        nodes.append(contentsOf: embedded.collection)
                        //if let nodes = nodes {
                            self.nodes = nodes.removeDuplicates()
                       // }
                    }
                }
                //return nodeCollections
            }
            catch let error as CoreError {
                print(error.message)
                //return nil
            }
        }
        
    }
}
