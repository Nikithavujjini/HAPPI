//
//  Colors.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 13/10/23.
//

import Foundation

let ACCENT_COLOR = "accent-color"
let GRID_ITEM_COLOR = "grid-item-bg"
let GRID_ITEM_BORDER = "grid-item-border"




//MARK: - Misc
let COLOR_BUTTON_BACKGROUND:String = "button-background"
let COLOR_CONTENT_BACKGROUND:String = "content-background"
let COLOR_WARNING:String = "warning"
let CAROUSEL_BACKGROUND:String = "carousel-background"
let CAROUSEL_ITEM_BACKGROUND:String = "carousel-item-background"


//MARK: - Text
let COLOR_TEXT_DARK_GREY:String = "text-dark-grey"
let COLOR_TEXT_LIGHT:String = "text-light"
let COLOR_TEXT_DARK:String = "text-dark"
let COLOR_TEXT_DEFAULT:String = "text-default"
let COLOR_TEXT_DISABLED:String = "text-disabled-gray"

//MARK: - List
let COLOR_LIST_ROW_BACKGROUND:String = "list-row-background"
let COLOR_LIST_LOAD_MORE_BACKGROUND:String = "list-load-more-background"
let COLOR_LIST_DIVIDER:String = "list-divider"

//MARK: - Navigation Bar
let COLOR_NAVIGATION_BAR_GRADIENT_TOP:String = "navigation-bar-gradient-top"
let COLOR_NAVIGATION_BAR_GRADIENT_BOTTOM:String = "navigation-bar-gradient-bottom"
let COLOR_NAVIGATION_BAR_TITLE:String = "navigation-bar-title"
let COLOR_NAVIGATION_BAR_DARK:String = "navigation-bar-dark"
let COLOR_NAVIGATION_BAR_OFFLINE:String = "offline-navigation-bg"
let COLOR_NAVIGATION_BAR_LIGHT:String = "navigation-bar-light"

//MARK: - Tab Bar
let COLOR_TAB_BAR_BACKGROUND:String = "tab-bar-background"
let COLOR_PROFILE_INITAL_BACKGROUND:String = "profile-initials-background"
let COLOR_SIGN_OUT:String = "sign-out"
let COLOR_TEXT_DARK_GRAY:String = "text-dark-gray"
let COLOR_TAB_BAR_SEPARATOR:String = "tab-bar-separator"
let COLOR_TAB_BAR_INACTIVE:String = "tab-bar-inactive"

let TEXT_COLOR_TASK_DETAIL:String = "Detail-Text"
//MARK: - Shortcut Screen
let COLOR_SHORT_CUT_ITEM_BACKGROUND:String = "shortcut-item-background"
let COLOR_SHORT_CUT_DEFAULT_FOLDER:String = "theme-stone-group1-1"

//MARK: - Loading Spinner
let COLOR_LOADING_SPINNER_BACKGROUND:String = "loading-spinner-background"
let COLOR_LOADING_SPINNER_CIRCLE_1:String = "loading-spinner-circle-1"
let COLOR_LOADING_SPINNER_CIRCLE_2:String = "loading-spinner-circle-2"
let COLOR_THREE_DOT_END:String = "three-dot-end-color"

//MARK: - About
let COLOR_LINK_TEXT:String = "hyperlink-text"
let COLOR_SEPRATOR_BACKGROUND:String = "seperator-background"

//MARK: - Profile
let COLOR_SHADOW_BACKGROUND:String = "shadow-background"

//MARK: - Input
let COLOR_INPUT_BACKGROUND:String = "input-background"
let COLOR_INPUT_BOTTOM_BORDER:String = "input-bottom-border"
let COLOR_INPUT_BOTTOM_BORDER_FOCUSED:String = "input-bottom-border-focused"
let COLOR_INPUT_BOTTOM_BORDER_ERROR:String = "input-bottom-border-error"
let COLOR_INPUT_PLACEHOLDER:String = "input-placeholder"
let COLOR_PROPERTIES_INITIALS_BG:String = "properties-initials-bg"
let COLOR_DATEPICKER_SELECTED_STATE: String = "date-select-color"
let COLOR_DATEPICKER_UNSELECTED_STATE: String = "date-unselect-color"
let COLOR_DATE_BUTTON_BACKGROUNG: String = "date-button-Bg"
let Date_TOPROW_SEPARATOR:String = "date-topbar-separator"

//Viewer
let COLOR_VIEWER_BACKGROUND:String = "viewer-background"

//OverView Thumbnail BG
let COLOR_THUMBNAIL_BACKGROUND:String = "thumbnail-background"

//MARK: - Sort
let COLOR_SORT_BUTTON_BACKGROUND:String = "sort-button-background"
let COLOR_OVERLAY_BLACK:String = "overlay-black"
let COLOR_OVERLAY_WHITE:String = "overlay-white"

//MARK: - ActionSheet
let COLOR_ACTION_SHEET_BACKGROUND:String = "action-sheet-background"
let COLOR_ACTION_SHEET_SHADOW:String = "action-sheet-shadow"
let COLOR_ACTION_SHEET_TITLE:String = "action-sheet-title"
let COLOR_ACTION_SHEET_ROW_BACKGROUND:String = "text-light-gray"
let COLOR_FILES_ACTION_SHEET_HEADER_BACKGROUND:String = "files-action-sheet-header-background"
let COLOR_FILES_ACTION_SHEET_DRAG_INDICATOR:String = "files-action-sheet-drag-indicator"
let COLOR_FILES_ACTION_SHEET_ACTIONS:String = "actions-color"
//Mark: - Swipe actions background
let COLOR_SWIPE_ACTION_BG:String = "swipe-actions-background"
let COLOR_SWIPE_ACTION_SELECTED_BG:String = "swipe-actions-selected-background"

//MARK: - Favorite
let FAV_HEADER_BACKGROUND:String = "fav-header-background"
let FAV_HEADER_BACKGROUND_UPDATED:String = "fav-header-bg-updated"
let FAV_HEADER_TEXT:String = "fav-header-text"
let FAV_CELL_HIGHLIGHT_COLOR:String = "favorite-cell-highlight"
let COLOR_BOTTOM_BAR_BACKGROUND:String = "bottom-bar-background"

//MARK: - Selected Modes
let SELECTED_CELL_BACKGROUND:String = "selected-icon-background"

let COLOR_BUTTON_HIGHLIGHT:String = "button-highlight-bg"
let PROGRESS_BAR_COLOR:String = "progressBarColor"
let LIST_ROW_DOWNLOAD:String = "list-row-download"
let LIST_ROW_UPLOAD_FAIL:String = "list-row-upload-fail"
let LIST_ROW_SEPARATOR:String = "list-row-separator"
let OFFLINE_SAVE_DISABLED:String = "offline-save"
let PIN_SCREEN_BACKGROUND:String = "pin-background"
let COLOR_COPY_HERE_HIGHLIGHT:String = "button-highlight-copy-here"

let VERIFIED_TEXT:String = "verified-text"

//MARK: - Security
let CHECKBOX_COLOR:String = "theme-indigo-group2-1"

//Offline
let COLOR_ONLINE_OVERLAY_BG:String = "online_overlay_bg"
let COLOR_OFFLINE_OVERLAY_BG:String = "offline_overlay_bg"
let COLOR_ERROR_MSG_OFFLINE:String = "offline_error_msg_color"

let LOCK_FACE_TOUCH_ID:String = "theme-indigo-group1-4"
let LOCK_SIGN_OUT:String = "lock_sign_out"


let COLOR_SEARCH_BORDER:String = "search-border-color"
let COLOR_SEARCH_BORDER_HIGHLIGHTED:String = "search-border-color-highlighted"

//MESSAGES
let COLOR_MESSAGE_DIVIDER_SUCCESS:String = "message_success_divider"
let COLOR_MESSAGE_DIVIDER_ERROR:String = "message_error_divider"
let COLOR_MESSAGE_DIVIDER_WARNING:String = "message_warning_divider"
let COLOR_SEARCH_FAVORITES_BG:String = "search-favorites-bg"
let ALPHABET_ERROR_COLOR:String = "alphabet-error-color"

let OFFLINE_LINK_COLOR:String = "offline-link-color"

let COLOR_SEARCH_OFFLINE_SORT_BAR:String = "search-offline-sort-bar"
let SEARCH_PLACEHOLDER_COLOR:String = "search-placeholder-color"
let RENAME_SAVE:String = "rename-save"
let RENAME_TEXTFIELD_BG:String = "rename-textfield-bg"
let COLOR_PROPERTIES_LABEL:String = "text-neutral-greys"
let COLOR_DISABLED_BUTTON:String = "disabled-button"

let KEYBOARD_BACKGROUND:String = "keyboard-background"
let KEYBOARD_ROW_SHADOW:String = "keypad-row-shadow"


//Properties
let COLOR_PROPERTIES_FIELD_BG:String = "properties-field-bg"
let COLOR_PROPERTIES_FIELD_BORDER:String = "properties-field-border"
let COLOR_DROPDOWN_OPTION_SELECTED:String = "dropdown-option-selected"
let COLOR_BUTTON_DISABLED:String = "properties-disabled-button"
let COLOR_USER_CLOSE_HIGHLIGHT:String = "user-close-selected-bg"
let COLOR_USER_HIGHLIGHT:String = "user-selected-bg"

//My Tasks
let COLOR_DUE_SOON_BG:String = "due-soon"
let COLOR_DUE_TODAY_BG:String = "due-today"
let COLOR_SHORTCUT_TASK_TITLE:String = "text-task-title"

//Copy/Move
let COLOR_COPYING_CELL_BG:String = "copying-cell-bg"
let COLOR_POPUP_SUBHEADER_BG:String = "popup-subheader-bg"


let SEARCH_SECTION_BG:String = "search-section-background"
let SHIMMER_CELL_BACKGROUND:String = "shimmer-background"
let FAV_SHIMMER_CELL_BACKGROUND:String = "fav-shimmer-background"


let EXPIRED_SEPARATOR = "expired-separator"
let COLOR_LIGHT_GREY:String = "light-grey"


let FACET_COUNT_BG:String = "facet-count-bg"
let FILTER_BORDER_COLOR:String = "FilterBorder"

let FILTER_CLEARALL_COLOR:String = "ClearAll"
let FACET_APPLY_DISABLED_COLOR:String = "facet-apply-disabled"
let FACET_SCREEN_BG:String = "facet_screen_bg"

let FACET_CHICKLET_BG_SELECTED:String = "facet_chicklet_bg_selected"
let FACET_CHICKLET_SELECTED_BORDER:String = "facet_chicklet_selcted_border"

let SIGNER_BG_COLOR:String = "signer-item-bg"
let SIGNATURE_STATUS_BG_COLOR:String = "signature_status_bg"
let SIGNATURE_PENDING_COLOR:String = "signature_pending_color"

let DELETED_USER_BG:String = "deleted-user-bg"
