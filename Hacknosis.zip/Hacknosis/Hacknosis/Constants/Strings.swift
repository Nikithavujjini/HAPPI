//
//  Strings.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import Foundation

//MARK: - Alerts
public let OK:String = "OK".localized
public let Done:String = "Done".localized
public let NO_INTERNET:String = "no_internet".localized
public let NO_INTERNET_MESSAGE:String = "no_internet_message".localized

//MARK: - Home
public let HOME:String = "Home".localized

//MARK: - Action Sheet Items
public let FAVORITES:String = "Favorites".localized

public let SELECT_TEXT:String = "Select".localized

public let ADD_FAVORITE:String = "Add favorite".localized
public let ADD_VERSION:String = "Add version".localized

public let REMOVE_FAVORITE:String = "Remove favorite".localized
public let MARK_OFFLINE:String = "mark_offline".localized
public let REMOVE_OFFLINE:String = "remove_offline".localized

public let ACTION_SHEET_SELECTED_ITEMS:String = "action_sheet_selected_items".localized
public let ACTION_SHEET_SELECTED_SINGLE_ITEM:String = "action_sheet_selected_item".localized
public let GOTOLOCATION:String = "gotolocation".localized

//MARK: - Profile
public let PROFILE:String = "Profile".localized
public let SIGN_OUT:String = "Sign out".localized
public let ABOUT_CORE_CONTENT: String = "About".localized

//MARK: - Files List
public let EMPTY_LIST_MESSAGE:String = "empty_list_message".localized
public let MODIFIED_DATE:String = "modified_static".localized

//MARK: - Branding
public let CORE_CONTENT:String = "Core Content".localized

//MARK: - Environments
public let COPYRIGHT_NORTH_AMERICA:String = "copyright_north_america".localized

//MARK: - Login
public let NEXT:String = "Next".localized
public let SUBSCRIPTION_NAME:String = "Subscription name".localized

//MARK: - Errors
public let ERROR:String = "Error".localized
public let ERROR_ENVIRONMENT_NOT_FOUND:String = "error_environment_not_found".localized
public let ERROR_UNKNOWN_ERROR:String = "error_unknown_error".localized
public let ERROR_LOGIN_GENERIC:String = "error_login_generic".localized

//MARK: - About
public let ABOUT = "About".localized
public let ERROR_ITEM_CANNOT_BE_ACCESSED:String = "Item cannot be accessed.".localized
public let ABOUT_HEADER_P1 = "about_header_p1".localized
public let ABOUT_HEADER_P2 = "about_header_p2".localized
public let ABOUT_BODY_P1 = "about_body_p1".localized
public let ABOUT_BODY_P2_1 = "about_body_p2_1".localized
public let ABOUT_BODY_P2_2 = "about_body_p2_2".localized
public let ABOUT_BODY_P2_3 = "about_body_p2_3".localized
public let ABOUT_BODY_P2_4 = "about_body_p2_4".localized
public let ABOUT_BODY_P2_5 = "about_body_p2_5".localized
public let ABOUT_BODY_P3_1 = "about_body_p3_1".localized
public let ABOUT_BODY_P3_2 = "about_body_p3_2".localized
public let ABOUT_BODY_P3_3 = "about_body_p3_3".localized
public let ABOUT_WARNING = "Warning".localized
public let ABOUT_WARNING_TEXT = "warning_text".localized
public let ABOUT_CONTACT_INFO = "contact_info".localized
public let ABOUT_OPENTEXT = "OpenText Website".localized
public let ABOUT_PRIVACY = "Privacy Policy".localized
public let ABOUT_LICENSE = "License Terms".localized
public let ERROR_SUBSCRIPTION_NOT_FOUND:String = "error_subscription_not_found".localized
public let SEARCH_TEXT:String = "Search".localized
public let SEARCH_FROM_HERE:String = "Search from here".localized
public let SEARCH_FAVORITES:String = "Search favorites".localized
public let SEARCH_USERS:String = "Search users".localized

public let SEARCH_OFFLINE:String = "search_offline".localized
public let EMPTY_FAVORITES_LIST = "empty_favorites_message".localized
public let EMPTY_FAVORITES_GROUP:String = "empty_favorites_group_message".localized

//MARK: - Envirionments
public let ENVIRONMENT:String = "Environment".localized

//Document errors
public let FILE_ERROR:String = "File Error".localized
public let FILE_LOADING:String =  "loading_percentage".localized
public let FILE_CANT_OPEN:String =  "Cannot open file".localized
public let FILE_DONT_EXIST:String = "File Doesn't exist".localized
public let FILE_CANT_DOWNLOAD:String =  "Cannot download file".localized
public let FILE_DOWNLOADING:String =  "downloading_percentage".localized
public let FILE_DELETED:String =  "file_deleted".localized

public let SELECT_YOUR_LOCATION:String = "Select your location".localized

//Search
public let SEARCH_WITHIN:String = "search_within".localized
public let EMPTY_SEARCH_RESULTS:String = "empty_search_results".localized

//MARK: - Sort Options
public let NAME:String = "Name".localized
public let MODIFIED:String = "Modified".localized
public let SIZE:String = "Size".localized
public let ADDED:String = "Added".localized
public let RELEVANCE:String = "Relevance".localized
public let ASSIGNED:String = "Assigned".localized
public let DUE:String = "Due".localized
public let SORT_BY:String = "Sort by".localized
public let ACCESSIBILITY_SORT_HEADER_NAME_ASCENDING:String = "sort_header_name_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_NAME_DESCENDING:String = "sort_header_name_descending".localized
public let ACCESSIBILITY_SORT_HEADER_MODIFIED_ASCENDING:String = "sort_header_modified_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_RELEVANCE:String = "sort_header_relevance".localized
public let ACCESSIBILITY_SORT_HEADER_MODIFIED_DESCENDING:String = "sort_header_modified_descending".localized
public let ACCESSIBILITY_SORT_HEADER_SIZE_ASCENDING:String = "sort_header_size_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_SIZE_DESCENDING:String = "sort_header_size_descending".localized
public let ACCESSIBILITY_SORT_HEADER_ADDED_ASCENDING:String = "sort_header_added_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_ADDED_DESCENDING:String = "sort_header_added_descending".localized
public let ACCESSIBILITY_SORT_BACKGROUND_DISMISS:String = "Dismiss".localized


//MARK: - Swipe Actions & Files
public let ACCESSIBILITY_NODE_TYPE_LINK:String = "link".localized
public let ACCESSIBILITY_NODE_TYPE_FOLDER:String = "folder".localized
public let ACCESSIBILITY_NODE_TYPE_FILE:String = "file".localized
public let ACCESSIBILITY_NODE_LABEL_FILE:String = "node_accessibility_label".localized
public let ACCESSIBILITY_NODE_LABEL_FOLDER:String = "node_accessibility_label_folder".localized
public let ACCESSIBILITY_MARK_FAVORITE:String = "favorite_accessibility".localized
public let ACCESSIBILITY_MARK_UNFAVORITE:String = "unfavorite_accessibility".localized
public let ACCESSIBILITY_MARK_OFFLINE:String = "offline_accessibility".localized
public let ACCESSIBILITY_REMOVE_OFFLINE:String = "remove_offline_accessibility".localized
public let ACCESSIBILITY_MARK_SELECT:String = "select_accessibility".localized
public let ACCESSIBILITY_MORE_ACTIONS:String = "more_accessibility".localized
public let ACCESSIBILITY_GO_TO_LOCATION:String = "goto_accessibility".localized
public let ACCESSIBILITY_REMOVE_ALL:String = "remove_all_offline_accessibility".localized
public let ACCESSIBILITY_OFFLINE_DELETE:String = "delete_accessibility".localized
public let ACCESSIBILITY_OFFLINE_RETRY:String = "retry_download_accessibility".localized
public let ACCESSIBILITY_GROUP:String = "group_accessibility".localized
public let ACCESSIBILITY_ACTION_BACKGROUND_DISMISS:String = "Dismiss".localized
public let ACCESSIBILITY_NODE_SAVED_TO_FAVORITES:String = "node_saved_to_favorites_label".localized
public let ACCESSIBILITY_FAVORITE_EXPAND_COLLAPSE:String = "Double tap to expand/collapse".localized
public let ACCESSIBILITY_NODE_SAVED_TO_OFFLINE:String = "node_saved_to_offline_label".localized
public let ACCESSIBILITY_NODE_SAVED_TO_OFFLINE_FAVORITES:String = "node_save_to_offlines_favorites".localized
public let ACCESSIBILITY_MORE_ACTIONS_SWIPE:String = "more_swipe_accessibility".localized
public let ACCESSIBILITY_SEND_SIGNATURE_ACTION:String = "node_save_to_offlines_favorites".localized
//MARK: - Selection Modes
public let CANCEL:String = "Cancel".localized
public let SELECTED_HEADER_TITLE:String = "selected_title".localized
public let ACCESSIBILITY_ACTION_HINT:String = "accessibility_action_hint".localized


public let ACCESSIBILITY_TAB_BAR:String = "tab_bar".localized
public let ACCESSIBILITY_TAB:String = "tab_accessibility".localized
public let NAVIGATION_BACK_BUTTON_TITLE = "back".localized
public let ACCESSIBILITY_ENVIRONMENT_LABEL:String = "sign_in_environment".localized
public let ACCESSIBILITY_ENVIRONMENT_HINT:String = "edit".localized
public let ACCESSIBILITY_SHORTCUT_LABEL:String = "shortcut_accessibility".localized
public let ACCESSIBILITY_CORE_CONTENT:String = "core_content_accessibility".localized

public let FILE_SIZE:String = "file_size".localized
public let LAST_MODIFIED:String = "last_modified".localized
public let NO_ITEMS:String = "no_items".localized
public let ITEMS:String = "items".localized
public let ACCESSIBILITY_SELECT_AUTO_SUMMARY:String = "accessibility_select_auto_summary".localized
public let ACCESSIBILITY_SELECTED_ROW_ACTION_TITLE:String = "accessibility_selected_row_action".localized
public let ACCESSIBILITY_DESELECTED_ROW_ACTION_TITLE:String = "accessibility_deselected_row_action".localized
public let ACCESSIBILITY_SELECTED_ROW_ACTIONS_TITLE:String = "accessibility_selected_row_actions".localized
public let ACCESSIBILITY_DESELECTED_ROW_ACTIONS_TITLE:String = "accessibility_deselected_row_actions".localized


public let ACCESSIBILITY_SORT_BACKGROUND_HINT:String = "sort_background_hint".localized
public let ACCESSIBILITY_SORT_TOGGLE_HINT:String = "sort_toggle_hint".localized
public let ACCESSIBILITY_SORT_SELECTED_SUFFIX:String = "selected".localized
public let ACCESSIBILITY_SORT_ITEM_NAME_ASCENDING:String = "sort_item_name_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_NAME_DESCENDING:String = "sort_item_name_descending".localized
public let ACCESSIBILITY_SORT_ITEM_MODIFIED_ASCENDING:String = "sort_item_modified_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_MODIFIED_DESCENDING:String = "sort_item_modified_descending".localized
public let ACCESSIBILITY_SORT_ITEM_SIZE_ASCENDING:String = "sort_item_size_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_SIZE_DESCENDING:String = "sort_item_size_descending".localized
public let ACCESSIBILITY_SORT_ITEM_ADDED_ASCENDING:String = "sort_item_added_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_ADDED_DESCENDING:String = "sort_item_added_descending".localized
public let ACCESSIBILITY_SORT_ITEM_RELEVANCE:String = "sort_item_relevance".localized

//MARK: - OFFLINE
public let OFFLINE:String = "Offline".localized
public let OFFLINE_SCREEN_TITLE:String = "offline_screen_title".localized
public let DOWNLOAD_CANCELLED:String = "Download cancelled.".localized
public let FILE_NOT_FOUND_ON_SERVER:String = "Cannot find this file on the server.".localized
public let FACE_ID:String = "face_id".localized
public let TOUCH_ID:String = "touch_id".localized
public let CREATE_PIN:String = "create_pin".localized
public let OFFLINE_AUTHENTICATION_HEADER = "offline_authentication_header".localized
public let OFFLINE_AUTHENTICATION_DESCRIPTION = "offline_authentication_description".localized
public let VERIFY_PIN:String = "verify_pin".localized
public let VERIFY_YOUR_PIN:String = "verify_your_pin".localized
public let VERIFY_EDIT:String = "verify_edit".localized
public let VERIFY_SAVE:String = "verify_save".localized
public let VERIFY_PIN_INCORRECT:String = "verify_pin_incorrect".localized
public let VERIFIED:String = "verified".localized
public let NOT_CONNECTED_TO_NETWORK:String = "not_connected_to_network".localized
public let ACTION_CANCELED:String = "action_canceled".localized
public let GO_TO_OFFLINE_FILES:String = "go_to_offline_files".localized
public let BACK_ONLINE:String = "you_are_back_online".localized
public let FILE_DOWNLOAD_SUCCESS_MSG:String = "file_download_success_message".localized
public let REDIRECTING_IN_MSG:String = "redirecting_in".localized
public let NETWORK_MINUTES:String = "network_minutes".localized
public let NETWORK_SECONDS:String = "network_seconds".localized
public let LOCK_INCORRECT_PIN:String = "lock_incorrect_pin".localized
public let LOCK_PIN_BACK_BUTTON:String = "lock_pin_back_button".localized
public let RETRY_TEXT:String = "Retry".localized

//MARK: - SECURITY

public let SECURITY:String = "Security".localized
public let OFFLINE_ACCESS:String = "offline_access".localized
public let SECURITY_BODY_P1:String = "security_body_p1".localized
public let SECURITY_BODY_P1_OFFLINEFILES:String = "security_body_p1_offlinefiles".localized
public let FACE_ID_TEXT:String = "face_id_text".localized
public let TOUCH_ID_TEXT:String = "touch_id_text".localized
public let PIN:String = "pin".localized
public let RESET_PIN:String = "reset_pin".localized
public let REMOVE_ALERT_TITLE:String = "remove_alert_title".localized
public let REMOVE_ALERT_MESSAGE:String = "remove_alert_message".localized
public let REMOVE:String = "remove".localized
public let ALERT_ACCESSIBILITY:String = "alert".localized
public let REMOVE_ALL:String = "remove_all".localized

public let CAPTURE_TEXT:String = "capture_text".localized
public let SCAN_DOCUMENT_TEXT:String = "scan_document".localized


public let ADD_FOLDER_TEXT:String = "add_folder_text".localized
public let UPLOAD_TEXT:String = "upload_text".localized
public let CAPTURE_ALERT_TITLE:String = "capture_alert_title".localized
public let CAPTURE_ALERT_MESSAGE:String = "capture_alert_message".localized
public let CAMERA_ALERT_TITLE:String = "camera_alert_title".localized
public let CAMERA_ALERT_MESSAGE:String = "camera_alert_message".localized
public let UPLOAD_HEADER:String = "upload_files".localized
public let PHOTOS_TEXT:String = "photos_text".localized
public let GALLERY_PHOTO_TEXT:String =  "gallery_photo_text".localized
public let BROWSE_FILES_TEXT:String = "browse_files".localized
public let FILES_TEXT:String = "files".localized
public let SEPARATOR:String = "separator".localized
public let ADD_CONTENT:String = "add_content".localized
public let ACTION_PROPERTIES:String = "action_properties".localized
public let MORE_TITLE:String = "More".localized

public let ACCESSIBILITY_SECURITY_UNLOCK:String = "accessibilty_security_unclock".localized
public let ACCESSIBILITY_ON:String = "on".localized
public let ACCESSIBILITY_OFF:String = "off".localized
public let ACCESSIBILITY_SECURITY_AUTO_SUMMARY:String = "accessibility_security_auto_summary".localized
public let ACCESSIBILITY_SETTING_HINT:String = "accessibility_setting_hint".localized
public let ACCESSIBILITY_CREATE_AUTO_SUMMARY:String = "accessibility_create_auto_summary".localized
public let ACCESSIBILITY_LOCK_SCREEN_AUTO_SUMMARY:String = "accessibility_lock_screen_auto_summary".localized
public let ACCESSIBILITY_DATE_EDIT_BUTTON = "properties_date_edit".localized
public let ACCESSIBILITY_TIME_EDIT_BUTTON = "properties_time_edit".localized

public let FAVOURITE_ADDED_TOAST_MESSAGE = "added_favourite_banner".localized
public let FAVOURITE_REMOVED_TOAST_MESSAGE = "removed_favourite_banner".localized
public let VERSION_ADDED_TOAST_MESSAGE = "added_version_banner".localized
public let VERSION_FAILED_TOAST_MESSAGE = "failed_version_banner".localized

public let SEARCH_ABOUT_RESULTS:String = "search_about_results".localized
public let SEARCH_ABOUT_RESULT:String = "search_about_result".localized
public let SEARCH_GROUP_RESULTS:String = "search_group_results".localized
public let SEARCH_GROUP_RESULTS_SINGLE:String = "search_group_results_single".localized
public let SEARCH_FAVORITES_GROUP:String = "search_favorites_group".localized
public let SEARCH_FAVORITES_GROUP_EXPAND:String = "search_favorites_group_expand".localized
public let SEARCH_FAVORITES_GROUP_COLLAPSE:String = "search_favorites_group_collapse".localized
public let LOCK_SCREEN_FACE_ID:String = "lock_screen_face_id".localized
public let LOCK_SCREEN_TOUCH_ID:String = "lock_screen_touch_id".localized
public let LOCK_SCREEN_PIN:String = "lock_screen_pin".localized
public let LOCK_SCREEN_BUTTON_HINT:String = "lock_screen_button_hint".localized

public let ENTER_PIN:String = "enter_pin".localized
public let TOUCH_ID_MESSAGE:String = "touch_id_message".localized
public let TOUCH_ID_OFFLINE_MESSAGE:String = "touch_id_offline_message".localized
public let NETWORK_LOST:String = "The Internet connection appears to be offline."
public let REQUEST_TIMED_OUT:String = "The request timed out."
public let ACCESSIBILITY_SEARCH_EDITING:String = "search_editing_accessibility".localized
public let ACCESSIBILITY_SEARCH_LOADING:String = "loading_acessibility".localized
public let ACCESSIBILITY_EMPTY_SEARCH_RESULTS:String = "empty_search_results_accessibility".localized
public let ACCESSIBILITY_SEARCH_RESULTS:String = "search_results_accessibility".localized
public let ACCESSIBILITY_SEARCH_HINT:String = "search_accessibility_hint".localized
public let ACCESSIBILITY_SEARCH_AUTOSUMMARY:String = "search_accessibility_autosummary".localized
public let ACCESSIBILITY_SEARCH_CLEAR:String = "seacrh_clear_accessibility".localized
public let ACCESSIBILITY_SEARCH_BAR_HINT:String = "search_bar_accessibility_hint".localized
public let ACCESSIBILITY_BANNER_DISMISS_HINT:String = "banner_dismiss_hint".localized
public let ACCESSIBILITY_BANNER_DETAILS_EXPANDED:String = "banner_detailse_expanded".localized
public let ACCESSIBILITY_BANNER_DETAILS_COLLAPSED:String = "banner_detailse_collapsed".localized
public let ACCESSIBILITY_BANNER_EXPAND_HINT:String = "banner_expand_hint".localized
public let ACCESSIBILITY_BANNER_COLLAPSE_HINT:String = "banner_collapse_hint".localized
public let ACCESSIBILITY_BANNER_RETRY_HINT:String = "banner_retry_hint".localized

public let ACCESSIBILITY_CALENDER_HINT:String =   "properties_calender_accessibility_hint".localized
public let ACCESSIBILITY_TIME_HINT:String =  "properties_time_accessibility_hint".localized
//MARK: - Messages
public let SINGLE_DOWNLOAD_SUCCESS:String = "single_download_file_success".localized
public let MULTIPLE_DOWNLOADs_SUCCESS:String = "multiple_download_file_success".localized
public let SINGLE_DOWNLOAD_FAIL:String = "single_download_file_fail".localized
public let MULTIPLE_DOWNLOADS_FAIL:String = "multiple_download_file_fail".localized
public let MULTIPLE_DOWNLOADS_SINGLE_FAIL:String = "multiple_downloads_single_file_fail".localized

public let SINGLE_UPLOAD_SUCCESS:String = "single_upload_file_success".localized
public let MULTIPLE_UPLOADS_SUCCESS:String = "multiple_upload_file_success".localized
public let MULTIPLE_DELETE_SUCCESS:String = "multiple_delete_node_success".localized
public let MULTIPLE_DELETE_FAIL:String = "multiple_delete_node_fail".localized
public let SINGLE_DELETE_NODE_FAIL:String = "single_delete_node_fail".localized

public let SINGLE_DELETE_SUCCESS:String = "multiple_delete_node_success".localized
public let SINGLE_DELETE_FAIL:String = "single_delete_fail".localized
public let FILE_DELETE_FAILED:String = "file_delete_failed".localized
public let FOLDER_DELETE_FAILED:String = "folder_delete_failed".localized
public let FOLDER_NOT_FOUND:String = "folder_not_found".localized
public let FILE_NOT_FOUND:String = "file_not_found".localized

public let SINGLE_UPLOAD_FAIL:String = "single_upload_file_fail".localized
public let MULTIPLE_UPLOADS_FAIL:String = "multiple_upload_file_fail".localized
public let MULTIPLE_UPLOADS_SINGLE_FAIL:String = "multiple_uploads_single_file_fail".localized

public let ALPHABETS_ERROR_MESSAGE:String = "alphabets_error".localized
public let DO_NOT_HAVE_ACCESS_TO_THE_FILE:String = "file_access_denied".localized
public let FILE_DOWNLOAD_FAILED:String = "file_download_failed".localized
public let FILE_UPLOAD_FAILED:String = "file_upload_failed".localized
public let BIOMETRICS_SETTINGS_ALERT_TITLE:String = "biometrics_settings_alert_title".localized
public let BIOMETRICS_SETTINGS_ALERT_MESSAGE:String = "biometrics_settings_alert_message".localized
public let SETTINGS:String = "settings".localized
public let BIOMETRICES_OFFLINE_HEADER:String = "biometric_offline_header".localized
public let TOUCH_ID_UNAVAILABLE:String = "touch_id_unavailable".localized
public let FACE_ID_UNAVAILABLE:String = "face_id_unavailable".localized
public let VIEW_SETTINGS:String = "view_settings".localized
public let BIOMETRIC_PERMISSION_TEXT:String = "permission_text".localized
public let SETTINGS_PRIVACY:String = "settings_privacy".localized
public let ACCESSIBILITY_EDIT_FAVORITE_NAME:String = "edit_favorite_accessibilty".localized
public let RENAME_FAVORITES_NAME:String = "rename_favorites_name".localized
public let RENAME_GROUP_NAME:String = "rename_group_name".localized
public let RENAME_TITLE:String = "rename_title".localized
public let RENAME_FILE:String = "file_rename".localized
public let DOWNLOAD_FILE:String = "Download".localized

public let RENAME_ERROR:String = "rename_error".localized
public let ACCESSIBILITY_RENAME_EMPTY:String = "favorite_name_empty_accessibility".localized
public let ACCESSIBILITY_RENAME_FILE_EMPTY:String = "accessibility_file_name_empty".localized
public let NAME_TITLE:String = "name_title".localized
public let ADD_FOLDER_PLACEHOLDER:String = "rename_placeholder".localized
public let RENAME_VALIDATION_ERROR:String = "rename_validation_error".localized
public let SSL_TITLE_ERROR:String = "ssl_error_title".localized
public let SSL_ERROR:String = "ssl_connection_error".localized
public let LOGIN_SSL_ERROR:String = "login_SSL_error".localized

//MARK: - Voice Over Messages
public let ENTER_TIME:String =  "enter_time".localized
public let ENTER_DATE:String = "enter_date".localized
public let ENTER_DATE_AND_TIME:String =  "enter_date_and_time".localized
public let FILE_RENAME_ERROR:String = "file_rename_error".localized
public let ADD_FOLDER_ERROR:String = "add_folder_error".localized

//MARK: - PROPERTIES
public let PROPERTIES_CREATED:String = "created_text".localized
public let PROPERTIES_CREATED_BY:String = "createdby_text".localized
public let PROPERTIES_LOCKED_BY:String = "locked_by_text".localized

public let PROPERTIES_MODIFIED:String = "modified_text".localized
public let PROPERTIES_OWNED_BY:String = "ownedby_text".localized
public let PROPERTIES_FORMAT:String = "format_text".localized
public let PROPERTIES_SIZE:String = "size_text".localized
public let PROPERTIES_VERSION:String = "Version".localized

public let PROPERTIES_DESCRIPTION:String = "description".localized
public let PROPERTIES_NO_VALUE:String = "No value".localized
public let PROPERTIES_URL:String = "URL".localized
public let DISCARD_TEXT:String = "Discard".localized
public let PROPERTIES_DISCARD_CHANGES:String = "properties_discard_changes".localized
public let PROPERTIES_DISCARD_FILE_UPLOAD:String = "properties_discard_file_uploads".localized
public let PROPERTIES_DELETE_PHOTO:String = "properties_delete_photo".localized
public let PROPERTIES_DELETE_VIDEO:String = "properties_delete_video".localized
public let PROPERTIES_DELETE_SCAN:String = "properties_delete_scan".localized
public let PROPERTIES_ADD_FILE_TITLE:String = "properties_add_file_title".localized
public let PREVIEW_DELETE_SCANS:String = "preview_delete_scans".localized
public let PREVIEW_DELETE_SCAN:String = "preview_delete_scan".localized

public let PROPERTIES_ADD_PHOTO_TITLE:String = "properties_add_photo_title".localized
public let PROPERTIES_ADD_VIDEO_TITLE:String = "properties_add_video_title".localized
//Node formats
public let NODE_FORMAT_WEB_ADDRESS:String = "Web address".localized
public let NODE_FORMAT_AUDIO:String = "Audio".localized
public let NODE_FORMAT_COMPRESSED_FILE:String = "Compressed File".localized
public let NODE_FORMAT_IMAGE:String = "Image".localized
public let NODE_FORMAT_TEXT_DOC:String = "Text Document".localized
public let NODE_FORMAT_HTML_DOC:String = "Html Document".localized
public let NODE_FORMAT_XML_DOC:String = "Xml Document".localized
public let NODE_FORMAT_VIDEO:String = "Video".localized
public let NODE_FORMAT_WORD:String = "Microsoft Word".localized
public let NODE_FORMAT_PDF:String = "Portable Document Format".localized
public let NODE_FORMAT_PPT:String = "Microsoft Powerpoint".localized
public let NODE_FORMAT_PRESENTATION:String = "Presentation".localized
public let NODE_FORMAT_XLS:String = "Microsoft Excel".localized
public let NODE_FORMAT_SPREAD_SHEET:String = "Spreadsheet".localized
public let NODE_FORMAT_FORMULA:String = "Formula".localized
public let NODE_FORMAT_PUBLISHER:String = "Microsoft Publisher".localized
public let NODE_FORMAT_VISIO:String = "Microsoft Visio".localized
public let NODE_FORMAT_MPP:String = "Microsoft Project".localized
public let NODE_FORMAT_ONE:String = "Microsoft OneNote".localized
public let NODE_FORMAT_SDD:String = "Document template".localized
public let NODE_FORMAT_DWG:String = "Autocad Drawing".localized
public let NODE_FORMAT_DOCUMENT:String = "Document".localized
public let NODE_FORMAT_WORKSPACE:String = "Workspace".localized
public let NODE_FORMAT_FOLDER:String = "Folder".localized
public let NODE_FORMAT_GOOGLE_DOC:String = "Google Doc".localized
public let NODE_FORMAT_GOOGLE_SHEET:String = "Google Sheet".localized
public let NODE_FORMAT_GOOGLE_SLIDE:String = "Google Slide".localized

public let NODE_FORMAT_UNKNOWN:String = "Unknown".localized
public let NODE_FORMAT_ENTERPRISE_WORKSPACE = "Enterprise Workspace".localized
public let ACCESSIBILITY_PROPERTIES_OPEN_CATEGORY = "accessibility_properties_open_category".localized

//Properties Placeholders
public let PROPERTIES_PLACEHOLDER_TEXT:String = "properties_placeholder_text".localized
public let PROPERTIES_PLACEHOLDER_VALUE:String = "properties_placeholder_value".localized
public let PROPERTIES_PLACEHOLDER_SELECT:String = "properties_placeholder_select".localized
public let PROPERTIES_PLACEHOLDER_DESCRIPTION:String = "properties_placeholder_description".localized
public let PROPERTIES_PLACEHOLDER_WEB_ADDRESS:String = "properties_placeholder_web_address".localized
public let PROPERTIES_PLACEHOLDER_ADD_ITEMS:String = "properties_placeholder_add_items".localized
public let PROPERTIES_PLACEHOLDER_ADD_USER:String = "properties_placeholder_add_user".localized
public let PROPERTIES_PLACEHOLDER_ADD_USERS:String = "properties_placeholder_add_users".localized
public let PROPERTIES_PLACEHOLDER_ADD_USER_OR_GROUP:String = "properties_placeholder_add_user_or_group".localized
public let PROPERTIES_SELECT_NONE = "properties_select_none".localized
public let ACCESSIBILITY_PROPERTIES_EDIT_BUTTON = "properties_edit_properties".localized
public let PROPERTIES_GENERAL = "properties_general".localized
public let PROPERTIES_TEXT_FIELD_ACCESSIBILITY_HINT = "properties_textfield_accessibility_hint".localized
public let PROPERTIES_REQUIRED = "properties_required".localized
public let PROPERTIES_VALIDATION_ERROR_NUMBER = "properties_validation_error_number".localized
public let PROPERTIES_VALIDATION_ERROR_INTEGER = "properties_validation_error_integer".localized
public let PROPERTIES_FIELD_EDITING_START = "properties_field_editing_accessibility_start".localized
public let PROPERTIES_FIELD_EDITING_END = "properties_field_editing_accessibility_end".localized
public let PROPERTIES_MULTI_FIELD_VALUES_COUNT = "properties_multi_field_values_count".localized
public let PROPERTIES_MULTI_FIELD_VALUES_NUMBER = "properties_multi_field_item_number".localized
public let PROPERTIES_MULTI_FIELD_REMOVE = "properties_multi_field_item_remove".localized
public let ACCESSIBILITY_TOGGLE_HINT = "accessibility_toggle_hint".localized

public let PROPERTIES_SELECT_TYPE = "Select type".localized

public let STRING_NONE = "None".localized

public let PROPERTIES_EDIT_VALIDATION_ERRORS = "properties_edit_errors_cont".localized
public let PROPERTIES_EDIT_VALIDATION_ONE_ERROR = "properties_edit_one_error".localized
public let PROPERTIES_SHOW_ONLY_REQUIRED_FIELDS = "show_only_required_fields".localized
public let PROPERTIES_APPLY_TO_ALL = "properties_apply_to_all".localized

public let ALPHABET_ONE:String = "1".localized
public let ALPHABET_TWO:String = "2".localized
public let ALPHABET_THREE:String = "3".localized
public let ALPHABET_FOUR:String = "4".localized
public let ALPHABET_FIVE:String = "5".localized
public let ALPHABET_SIX:String = "6".localized
public let ALPHABET_SEVEN:String = "7".localized
public let ALPHABET_EIGHT:String = "8".localized
public let ALPHABET_NINE:String = "9".localized
public let ALPHABET_ZERO:String = "0".localized

public let ALPHABET_ABC:String = "ABC".localized
public let ALPHABET_DEF:String = "DEF".localized
public let ALPHABET_GHI:String = "GHI".localized
public let ALPHABET_JKL:String = "JKL".localized
public let ALPHABET_MNO:String = "MNO".localized
public let ALPHABET_PQRS:String = "PQRS".localized
public let ALPHABET_TUV:String = "TUV".localized
public let ALPHABET_WXYZ:String = "WXYZ".localized
public let DELETED:String = "deleted".localized
public let KEYBOARD:String = "Keyboard".localized

//Upload

public let CAMERA_UNAVAILABLE_TITLE:String = "camera_unavailable".localized
public let CAMERA_UNAVAILABLE_MESSAGE:String = "camera_unavailable_message".localized
public let DELETE_NODE_HEADER:String = "delete_node_header".localized
public let FILE_ITEM_DELETE_DESCRIPTION:String = "file_item_delete_description".localized
public let FOLDER_ITEM_DELETE_DESCRIPTION:String = "folder_item_delete_description".localized
public let WORKSPACE_ITEM_DELETE_DESCRIPTION:String = "workspace_item_delete_description".localized
public let MULTIPLE_ITEM_DELETE_DESCRIPTION:String = "multiple_item_delete_description".localized
public let DELETE_FOLDER_SUCCESS_MESSAGE:String = "delete_folder_success_message".localized
public let DELETE_WORKSPACE_SUCCESS_MESSAGE:String = "delete_workspace_success_message".localized
public let DELETE_FILE_SUCCESS_MESSAGE:String = "delete_file_success_message".localized
public let DELETE_WEB_ADDRESS_SUCCESS_MESSAGE:String = "delete_web_address_success_message".localized
public let DELETE_NODE_FAILURE_MESSAGE:String = "delete_node_failure_message".localized

public let UPLOAD_IMAGE_NAME:String = "upload_image_name".localized
public let UPLOAD_VIDEO_NAME:String = "upload_video_name".localized
public let UPLOAD_PDF_NAME:String = "upload_pdf_name".localized

public let FOLDER_NAME:String = "folder_name".localized
public let ADD_TEXT:String = "Add".localized
public let FOLDER_NAME_EMPTY_ACCESSIBILITY:String = "folder_name_empty_accessibility".localized
public let DUPLICATE_FILES_TITLE:String = "duplicate_files_title".localized
public let DUPLICATE_FILES_DESCRIPTION:String = "duplicate_files_description".localized
public let DUPLICATE_FILES_CONTINUE:String = "duplicate_files_continue".localized
public let DUPLICATE_FILES_SKIP_CONFLICTS:String = "duplicate_files_skip_conflicts".localized
public let DUPLICATE_FILES_ALERT_DESCRIPTION:String = "duplicate_files_alert_description".localized
public let UPLOADING_TEXT:String = "uploading_text".localized
public let APPLY_ALL_AUTO_SUMMARY_SHOW:String = "apply_all_auto_summary_show".localized
public let APPLY_ALL_AUTO_SUMMARY_HIDE:String = "apply_all_auto_summary_hide".localized
public let PROPERTIES_MULTI_FIELD_ITEMS_COUNT = "properties_multi_field_items_count".localized
public let MULTIPLE_VALUES_COPIED_ACCESSIBILITY = "multiple_values_copied_accessibility".localized
public let VALUE_COPIED_ACCESSIBILITY = "value_copied_accessibility".localized
public let DOCUMENT_TYPE_AUTO_SUMMARY:String = "document_type_auto_summary".localized
public let PROPERTIES_MULTI_FIELD_ITEMS_SINGLE = "properties_multi_field_items_single".localized
public let PROPERTIES_MULTI_FIELD_VALUES_SINGLE = "properties_multi_field_values_single".localized
public let JUST_NOW_TEXT = "just_now_text".localized

public let FILES_LIST_COULD_NOT_BE_UPLOADED = "file_list_upload_failed".localized
public let BANNER_LIST_COULD_NOT_BE_UPLOADED:String = "banner_list_upload_failed".localized
public let ZERO_FILE_SIZE_UPLOAD:String = "zero_file_size_upload".localized

//My Tasks
public let MY_TASKS_TITLE = "my_tasks_title".localized
public let DUE_SOON = "due_soon".localized
public let DUE_TODAY = "due_today".localized
public let OVERDUE = "overdue".localized
public let DUE_STATIC = "due_static".localized
public let ASSIGNED_STATIC = "assigned_static".localized


//My Tasks
public let ATTACHMENTS_TITLE = "attachments_title".localized
public let ATTACHMENTS_COUNT = "attachments_count".localized
public let SEARCH_ATTACHMENTS = "search_attachments".localized
public let SEARCH_MY_TASKS = "search_my_tasks".localized
public let EMPTY_TASKS_LIST_MESSAGE = "empty_tasks_list_message".localized
public let SEND = "send_text".localized
public let APPROVE_TEXT = "approve_text".localized
public let REJECT_TEXT = "reject_text".localized
public let CLAIM_TASK_TEXT = "claim_text".localized
public let RE_ASSIGN_TASK_TEXT = "reassign_text".localized
public let COMMENTS = "comments".localized
public let ADD_COMMENT = "add_comment".localized
public let IN_PROGRESS:String = "in_progress".localized

public let TYPE = "Type".localized
public let CREATED_BY = "Created_by".localized
public let STATUS = "Status".localized
public let TOMORROW = "tomorrow".localized
public let TODAY = "today".localized
public let ONEWEAK = "1_week".localized
public let DAYS = "days".localized
public let ONEDAY = "1_day".localized
public let HOURS = "hours".localized
public let ONEHOUR = "1_hour".localized
public let MINUTES = "minutes".localized
public let ONEMINUTE = "1_minute".localized
public let ONEWEAK_AGO = "1_week_ago".localized
public let DAYS_AGO = "days_ago".localized
public let ONEDAY_AGO = "1_day_ago".localized
public let HOURS_AGO = "hours_ago".localized
public let ONEHOUR_AGO = "1_hour_ago".localized
public let MINUTES_AGO = "minutes_ago".localized
public let ONEMINUTE_AGO = "1_minute_ago".localized
public let ACCESSIBILITY_SHORTCUT_TASK:String = "shortcut_task_accessibility".localized
public let ACCESSIBILITY_SORT_HEADER_ASSIGNED_ASCENDING:String = "sort_header_assigned_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_ASSIGNED_DESCENDING:String = "sort_header_assigned_descending".localized
public let ACCESSIBILITY_SORT_HEADER_DUE_ASCENDING:String = "sort_header_due_ascending".localized
public let ACCESSIBILITY_SORT_HEADER_DUE_DESCENDING:String = "sort_header_due_descending".localized

public let ACCESSIBILITY_SORT_ITEM_ASSIGNED_ASCENDING:String = "sort_item_assigned_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_ASSIGNED_DESCENDING:String = "sort_item_assigned_descending".localized
public let ACCESSIBILITY_SORT_ITEM_DUE_ASCENDING:String = "sort_item_due_ascending".localized
public let ACCESSIBILITY_SORT_ITEM_DUE_DESCENDING:String = "sort_item_due_descending".localized


public let ACCESSIBILITY_TASK_LIST_ITEM_DUE_TEXT:String = "my_task_list_item_due_accessibility".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_OVERDUE_TEXT:String = "my_task_list_item_overdue_accessibility".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_OVERDUE_DATE_TEXT:String = "my_task_list_item_overdue_date_accessibility".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_DUE_DATE_TEXT:String = "my_task_list_item_due_date_accessibility".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_DUE_TODAY_TEXT:String = "my_task_list_item_due_today_accessibility".localized


public let ACCESSIBILITY_TASK_LIST_ITEM_ASSIGNED_TEXT:String = "my_task_list_item_assigned_accessibility".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_GROUP_NAME_TEXT:String = "my_task_list_item_group_name_accessibility".localized
public let TO_TEXT:String = "to_text".localized


public let COPY:String = "Copy".localized
public let MOVE:String = "Move".localized
public let COPY_ONE_FILE_COUNT:String = "copy_one_file_message".localized
public let COPY_FILES_COUNT:String = "copy_files_message".localized
public let MOVE_ONE_FILE_COUNT:String = "move_one_file_message".localized
public let MOVE_FILES_COUNT:String = "move_files_message".localized
public let CURRENT_LOCATION:String = "Current_location".localized
public let COPY_HERE_TEXT:String = "copy_here".localized
public let MOVE_HERE_TEXT:String = "move_here".localized

public let SELECT_LOCATION_TEXT:String = "select_location".localized

public let SINGLE_COPY_FAIL:String = "single_copy_file_fail".localized
public let MULTIPLE_COPY_FAIL:String = "multiple_copy_file_fail".localized
public let MULTIPLE_COPY_SINGLE_FAIL:String = "multiple_copy_single_file_fail".localized

public let SINGLE_COPY_SUCCESS:String = "single_copy_file_success".localized
public let MULTIPLE_COPY_SUCCESS:String = "multiple_copy_file_success".localized

public let SINGLE_MOVE_FAIL:String = "single_move_file_fail".localized
public let MULTIPLE_MOVE_FAIL:String = "multiple_move_file_fail".localized
public let MULTIPLE_MOVE_SINGLE_FAIL:String = "multiple_move_single_file_fail".localized

public let SINGLE_MOVE_SUCCESS:String = "single_move_file_success".localized
public let MULTIPLE_MOVE_SUCCESS:String = "multiple_move_file_success".localized

public let COPYING_TEXT = "Copying".localized
public let MOVING_TEXT = "Moving".localized
public let ACCESSIBILITY_TASK_LIST_ITEM_ASSIGNED_DATE_TEXT:String = "my_task_list_item_assigned_date_accessibility".localized


public let ACCESSIBILITY_TASK_LIST_COUNT_ITEMS:String = "accessibility_task_list_count_items".localized
public let ACCESSIBILITY_TASK_LIST_COUNT_ITEM:String = "accessibility_task_list_count_item".localized

public let TASK_LIST_ITEM_SUCCESS_MESSAGE:String = "my_task_list_item_success_message".localized
public let TASK_LIST_ITEM_FAILURE_MESSAGE:String = "my_task_list_item_failure_message".localized

public let ACCESSIBILITY_ATTACHMENTS_SINGLE:String = "accessibility_attachments_single".localized
public let ACCESSIBILITY_ATTACHMENTS:String = "accessibility_attachments".localized

public let COPY_DUPLICATE_FILES_TITLE:String = "copy_duplicate_files_title".localized
public let MOVE_DUPLICATE_FILES_TITLE:String = "move_duplicate_files_title".localized
public let COPY_DUPLICATE_FILES_DESCRIPTION:String = "copy_duplicate_files_description".localized
public let COPY_DUPLICATE_FILES_ALERT_DESCRIPTION:String = "copy_duplicate_files_alert_description".localized


public let MOBILE_FAVORITES_LOCALIZED:String = "Mobile favorites".localized
public let WEB_FAVORITES:String = "Web favorites".localized
public let UNGROUPED:String = "Ungrouped".localized

//Advanced Search
public let SELECT_HERE_TEXT:String = "Select here".localized
public let SEARCH_WITHIN_TEXT:String = "Search within".localized
public let ADVANCED_SEARCH_TEXT:String = "Advanced search".localized
public let SHOW_LESS_TEXT:String = "Show less".localized
public let SHOW_MORE_TEXT:String = "Show more".localized
public let START_AN_STATIC_TEXT:String = "Start an".localized
public let SELECT_CATEGORY_TEXT:String = "Select category".localized

public let ACCESSIBILITY_RECENT_SEARCH_STATIC_TEXT:String = "recent_search_static_text".localized
public let ACCESSIBILITY_ADVANCED_SEARCH_STATIC_TEXT:String = "advanced_search_static_text".localized
public let ACCESSIBILITY_SEARCHED_FOR_TEXT:String = "searched_for".localized
public let ACCESSIBILITY_RECENT_SEARCH_EDIT:String = "recent_search_edit".localized
public let ACCESSIBILITY_START_ADVANCED_SEARCH:String = "start_advanced_search".localized
public let ACCESSIBILITY_RECENT_SEARCH_HINT:String = "recent_search_hint".localized
public let ADVANCED_SEARCH_EMPTY_RESULTS_TEXT_TRY:String = "advanced_search_empty_results_text_try".localized
public let ADVANCED_SEARCH_EMPTY_RESULTS_TEXT_EDIT:String = "advanced_search_empty_results_text_edit".localized
public let ADVANCED_SEARCH:String = "advanced_search".localized
public let ADVANCED_SEARCH_TRY:String = "advanced_search_try".localized
public let ADVANCED_SEARCH_EDIT:String = "advanced_search_edit".localized
public let ADVANCED_SEARCH_CATEGORY_DELETE:String = "double_tap_to_delete".localized
public let ADD_CATEGORY_TEXT:String = "Add category".localized
public let FOUND_STATIC:String = "found_static".localized
public let DATE_RANGE_ERROR_VALIDATION_MSG:String = "date_range_validation_error_msg".localized
public let ACCESSIBILITY_LOCATION:String = "location_accessibility".localized

public let USER_PICKER_ACCESSIBILITY_HINT:String = "user_accessibility_hint".localized
public let MULTI_USER_PICKER_ACCESSIBILITY_HINT:String = "multi_user_accessibility_hint".localized
public let SWAP_TEXT:String = "swap".localized
public let DOCUMENT_TYPE_ALERT_MESSAGE:String = "document_type_alert_message".localized
public let DOCUMENT_TYPE_ALERT_TITLE:String = "document_type_alert_title".localized
public let WORKSPACE_TYPE_ALERT_TITLE:String = "workspace_type_alert_title".localized
public let CATEGORY_TYPE_ALERT_TITLE:String = "category_type_alert_title".localized

public let CATEGORY_SELECT_AUTO_SUMMARY:String = "category_type_auto_summary".localized


public let OPEN_THE_FILE = "open_the_file".localized
public let CLICK_TO_OPEN_THE_FILE_HINT = "double_tap_to_activate".localized
public let SHARED_FILE_CANT_OPEN:String =  "shared_item_error".localized
public let SHARED_ITEM:String =  "shared_item".localized
public let LINK_EXPIRED:String =  "link_expired".localized
public let LINK_EXPIRES_ON:String =  "link_expires_on".localized
public let SHARED_LINK_EXPIRES_ON:String =  "shared_link_expires_on".localized
public let ACCESS_EXPIRED_ON = "access_expired_on".localized
public let ACCESS_EXPIRED =  "access_expired".localized
public let CAROUSEL_PAGE_NUMBER =  "carousel_page_number".localized
public let CAROUSEL_ITEM_ACCESSIBILITY =  "carousel_item_accessibility".localized
public let CROP_TEXT =  "crop_text".localized
public let ADD_SCAN_TEXT =  "add_scan_text".localized
public let ADD_FILTER_TEXT =  "add_filter_text".localized
public let ROTATE_TEXT =  "rotate_text".localized
public let CROP_TOP_LEFT_TEXT =  "crop_top_left_text".localized
public let CROP_TOP_RIGHT_TEXT =  "crop_top_right_text".localized
public let CROP_BOTTOM_LEFT_TEXT =  "crop_bottom_left_text".localized
public let CROP_BOTTOM_RIGHT_TEXT =  "crop_bottom_right_text".localized
public let CROP_HINT_TEXT =  "crop_hint".localized
public let REORDER_TEXT =  "reorder_text".localized
public let URL_VALIDATION_ERROR = "url_validation_error".localized

//Facets
public let ACCESSIBILITY_SEARCH_FILTER_BUTTON = "search_add_filter_text".localized
public let FACETS_SCREEN_AUTO_SUMMARY:String = "facets_screen_auto_summary".localized
public let FACETS_SECTION_SELECTION_ITEM:String = "facets_section_selection_item".localized
public let FACETS_SECTION_SELECTION_ITEMS:String = "facets_section_selection_items".localized
public let DESELECTED_TITLE:String = "deselected_title".localized
public let RELEVANT_RESULT_TEXT:String = "relevant_result_text".localized
public let RELEVANT_RESULTS_TEXT:String = "relevant_results_text".localized

public let CLEAR_ALL_TEXT =  "clear_all".localized
public let FILTERS_TEXT =  "filters_text".localized

public let SORT_DIRECTION_MESSAGE_RELAVANCE = "sort_direction_message_ascending_relevance".localized
public let SORT_DIRECTION_MESSAGE_ASCENDING_NAME = "sort_direction_message_ascending_name".localized
public let SORT_DIRECTION_MESSAGE_DESSCENDING_NAME = "sort_direction_message_descending_name".localized
public let SORT_DIRECTION_MESSAGE_ASCENDING_MODIFIED = "sort_direction_message_ascending_modified".localized
public let SORT_DIRECTION_MESSAGE_DESCENDING_MODIFIED = "sort_direction_message_descending_modified".localized
public let SORT_DIRECTION_MESSAGE_ASCENDING_SIZE = "sort_direction_message_ascending_size".localized
public let SORT_DIRECTION_MESSAGE_DESCENDING_SIZE = "sort_direction_message_descending_size".localized
public let NUMBER_MAX_VALIDATION_ERROR =  "number_max_validation_error".localized
public let STRING_MAX_VALIDATION_ERROR =  "string_max_length_validation_error".localized
public let NUMBER_MIN_VALIDATION_ERROR =  "number_min_validation_error".localized
public let FACETS_SEARCH_PLACEHOLDER =  "facets_search_placeholder".localized
public let SELECTED_COUNT_TITLE =  "selected_count_title".localized
public let APPLY_TEXT =  "apply_text".localized
public let EDIT_FILTERS_ACCESSIBILITY =  "edit_filters_accessibility".localized
public let FILTER_RESULTS_COUNT =  "filter_results_count".localized
public let FILTERS_SELECTED_COLLAPSED =  "filters_selected_collapsed".localized // items append properties_multi_field_items_single, properties_multi_field_items_count
public let FILTERS_SECTION_HEADER_WITH_COUNT =  "filters_header_with_count".localized  // filter header with filter count
public let FILTERS_SECTION_HEADER_COUNT_SINGLE =  "filters_header_count_single".localized
public let FILTERS_CHICKLETS =  "filter_chickets".localized // properties_multi_field_item_number
public let ACCESSIBILITY_COLLAPSE_DETAILS =  "collapse_details_accessibility".localized

public let FILTER_THIS_WEEK =  "filter_this_week".localized
public let FILTER_THIS_MONTH =  "filter_this_month".localized
public let FILTER_LAST_MONTH =  "filter_last_month".localized
public let FILTER_LAST_6_MONTHS =  "filter_last_6_months".localized
public let FILTER_THIS_YEAR =  "filter_this_year".localized
public let FILTER_LAST_YEAR =  "filter_last_year".localized
public let FILTER_OLDER =  "filter_older".localized

public let FILTER_CREATION_DATE = "filter_creation_date".localized
public let FILTER_MODIFIED_DATE = "filter_modified_date".localized
public let FILTER_AUTHOR = "filter_author".localized
public let FILTER_ITEM_TYPE = "filter_item_type".localized
public let FILTER_DOC_TYPE = "filter_document_type".localized
public let FILTER_WORSPACE_TYPE = "filter_workspace_type".localized
public let FILTER_CATEGORY = "filter_category".localized
public let JAIL_BROKE_DEVICE_TEXT = "jailbreak_error".localized
public let SEND_SIGNATURE_TEXT = "send_signature_text".localized
public let CANCEL_SIGNATURE_TEXT = "cancel_signature_text".localized
public let DELETE_REQUEST = "delete_request".localized
public let DELETE_REQUEST_MESSAGE = "delete_request_message".localized
public let SIGNATURE_SENT_SUCCES_MESSAGE = "signature_sent_success".localized
public let SIGNATURE_SENT_FAILURE_MESSAGE = "signature_sent_failure".localized
public let SIGNATURE_CANCEL_SUCCESS_MESSAGE = "signature_cancel_success".localized
public let SIGNATURE_CANCEL_FAILURE_MESSAGE = "signature_cancel_failure".localized
public let CORE_SIGNATURE_TITLE = "core_signature_title".localized
public let PREPARING_SIGNATURE = "preparing_signature".localized
public let UPDATING_SIGNATURE = "updating_signature".localized
public let SIGNATURE_STATUS_TEXT = "signature_status_text".localized
public let REQUESTED_BY_TEXT = "requested_by_text".localized
public let OPEN_IN_CORE_SIGNATURE = "open_in_core_signature".localized
public let ACCESSIBILITY_SIGNED_USER = "accessibility_signed_user".localized
public let ACCESSIBILITY_NOT_SIGNED_USER = "accessibility_not_signed_user".localized
public let WAITING_FOR_ONE_SIGNATURE = "waiting_for_one_signature".localized
public let WAITING_FOR_MORE_SIGNATURES = "waiting_for_more_signatures".localized
public let AND_TEXT = "and_text".localized
public let SIGNATURES_PENDING_TEXT = "signatures_pending_text".localized
public let PENDING_SIGNATURE_TEXT = "pending_signature_text".localized
public let VIEW_STATUS_TEXT = "view_status_text".localized
public let CLAIM_SUCCESS_BANNER_TEXT = "claim_success_banner_text".localized
public let REASSIGN_SUCCESS_BANNER_TEXT = "reassign_success_banner_text".localized
public let CLAIMED_TASK_ERROR_TEXT = "claimed_task_error".localized
public let DETAIL_CLAIMED_TASK_ERROR_TEXT = "detail_claimed_task_error".localized

public let FACETS_ERROR_MSG = "facets_error_msg".localized
public let ACCESSIBILITY_NODE_TYPE_FOLDER_EMPTY:String = "folder_is_empty".localized
public let ACCOUNT_DELTED_TEXT:String = "account deleted".localized





