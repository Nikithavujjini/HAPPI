//
//  NodeModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import Foundation
import RealmSwift

final class CmsLink: Object {
    @Persisted var key = ""
    @Persisted var value : LinkRef?
}

final class User:Object, Decodable {
    
    //MARK: - Persisted variables
    @Persisted var id:String
    @Persisted var firstName:String?
    @Persisted var lastName:String?
    @Persisted var name:String?
    @Persisted var initials:String?
    @Persisted var role:String?
    @Persisted var email:String?
    @Persisted var tenantId:String?
    @Persisted var subscriptionNamespacePrefix:String?

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case initials
        case role = "role_name"
        case email
        case tenantId = "tenant_id"
        case subscriptionNamespacePrefix
        case firstName = "first_name"
        case lastName = "last_name"
    }
    override init() {
        super.init()
    }
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try values.decode(String.self, forKey: .id)
        
        if let name = try values.decodeIfPresent(String.self, forKey: .name) {
            self.name = name
        } else {
            self.name = nil
        }
        if let firstName = try values.decodeIfPresent(String.self, forKey: .firstName) {
            self.firstName = firstName
        } else {
            self.firstName = nil
        }
        if let lastName = try values.decodeIfPresent(String.self, forKey: .lastName) {
            self.lastName = lastName
        } else {
            self.lastName = nil
        }
        
        if let initials = try values.decodeIfPresent(String.self, forKey: .initials) {
            self.initials = initials
        } else {
            self.initials = nil
        }
        if let role = try values.decodeIfPresent(String.self, forKey: .role) {
            self.role = role
        } else {
            self.role = nil
        }
        if let email = try values.decodeIfPresent(String.self, forKey: .email) {
            self.email = email
        } else {
            self.email = nil
        }
        if let tenantId = try values.decodeIfPresent(String.self, forKey: .tenantId) {
            self.tenantId = tenantId
        } else {
            self.tenantId = nil
        }
        if let subscriptionNamespacePrefix = try values.decodeIfPresent(String.self, forKey: .subscriptionNamespacePrefix) {
            self.subscriptionNamespacePrefix = subscriptionNamespacePrefix
        } else {
            self.subscriptionNamespacePrefix = nil
        }
    }
}

class LinkRef: Object, Decodable {
    @Persisted var href: String?
}

final class CmsLinks:Object, Decodable {
    @Persisted var links = List<CmsLink>()
       
    
    //MARK: - initialization
    override init() {
        links = List<CmsLink>()
        super.init()
    }
    
    init(links:List<CmsLink>) {
        self.links = links
    }
    
    required init(from decoder: Decoder) throws {
        super.init()
        let container = try decoder.container(keyedBy: CustomCodingKeys.self)
        for key in container.allKeys {
            if let value = try? container.decodeIfPresent(LinkRef.self, forKey: CustomCodingKeys(stringValue: key.stringValue)!) {
                let cmsLink = CmsLink()
                cmsLink.key = key.stringValue
                cmsLink.value = value
                links.append(cmsLink)
            }
        }
    }
}

struct CustomCodingKeys: CodingKey {
    var stringValue: String
    init?(stringValue: String) {
        self.stringValue = stringValue
    }
    
    var intValue: Int?
    init?(intValue: Int) {
        return nil
    }
}

class NodeModel:Object, Decodable, Identifiable {
    //MARK: - Persisted Variables
    @Persisted var id:String
    @Persisted var name:String
    @Persisted var mimeType:String?
    @Persisted var type:String
    @Persisted var parentId:String?
   // @Persisted var typeId:Int?
    @Persisted var contentSize:Int?
    @Persisted var updateTime:String
   // @Persisted var url:String?
   // @Persisted var reserved:Bool = false
    @Persisted var cmsLinks:CmsLinks?
//    @Persisted var cmsCategory:String?
//    @Persisted var cmsType:String?
//    @Persisted var childrenCount:Int?
//
//    @Persisted var parentId:String?
    @Persisted var versionNo:Int = 1
//    @Persisted var originalFileName:String?
    //used for offline node
//    @Persisted var offlineUrl:String? = nil
//    @Persisted var errorMessage:String? = nil
//    @Persisted var isPermanentError:Bool = false
//    @Persisted var offlineTimeStamp:TimeInterval = 0
//    @Persisted var typeName:String?
    @Persisted var owner:User?
//    @Persisted var modifiedBy:User?
//    @Persisted var createdBy:User?
    
//    @Persisted var shortDescription:String?
    
//    var isEmpty: Bool?
    
//    is_emptyis_empty
    
   
    
    

    var formattedTime:String? = nil
    var imageName: String {
        
            
                
                switch mimeType {
                    //Word
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/msword",
                    "application/vnd.ms-word.document.macroenabled.12",
                    "application/vnd.ms-word.template.macroenabled.12",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.template":
                    return ASSET_IMAGE_FILE_TYPE_WORD
                    //Excel
                case "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
                    "application/vnd.ms-excel.sheet.macroEnabled.12",
                    "application/vnd.ms-excel.template.macroEnabled.12",
                    "application/vnd.ms-excel.addin.macroEnabled.12",
                    "application/vnd.ms-excel.sheet.binary.macroEnabled.12":
                    return ASSET_IMAGE_FILE_TYPE_EXCEL
                    //PowerPoint
                case "application/vnd.ms-powerpoint",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    "application/vnd.openxmlformats-officedocument.presentationml.template",
                    "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
                    "application/vnd.ms-powerpoint.addin.macroEnabled.12",
                    "application/vnd.ms-powerpoint.presentation.macroEnabled.12",
                    "application/vnd.ms-powerpoint.template.macroEnabled.12",
                    "application/vnd.ms-powerpoint.slideshow.macroEnabled.12":
                    return ASSET_IMAGE_FILE_TYPE_POWERPOINT
                case "application/vnd.ms-project",
                    "application/msproj",
                    "application/msproject",
                    "application/x-msproject",
                    "application/x-ms-project",
                    "application/mpp":
                    return ASSET_IMAGE_FILE_TYPE_PROJECT
                    //Zip
                case "application/x-rar-compressed",
                    "application/zip",
                    "application/x-zip",
                    "application/x-zip-compressed":
                    return ASSET_IMAGE_FILE_TYPE_ZIP
                    //XML
                case "text/xml":
                    return ASSET_IMAGE_FILE_TYPE_XML
                    //HTML
                case "text/html":
                    return ASSET_IMAGE_FILE_TYPE_HTML
                    //Formula
                case "application/vnd.oasis.opendocument.formula",
                    "application/vnd.sun.xml.math",
                    "application/vnd.stardivision.math",
                    "application/x-starmath":
                    return ASSET_IMAGE_FILE_TYPE_FORMULA
                    //Presentation
                case "application/x-iwork-keynote-sffkey",
                    "application/vnd.wolfram.mathematica",
                    "application/vnd.wolfram.player",
                    "application/vnd.oasis.opendocument.presentation",
                    "application/vnd.oasis.opendocument.presentation-template",
                    "application/vnd.sun.xml.impress",
                    "application/vnd.sun.xml.impress.template",
                    "application/vnd.stardivision.impress",
                    "application/vnd.stardivision.impress-packed",
                    "application/x-starimpress",
                    "application/vnd.lotus-freelance",
                    "application/vnd.corel-presentations",
                    "application/vnd.ms-officetheme":
                    return ASSET_IMAGE_FILE_TYPE_PRESENTATION
                    //Spreadsheet
                case "application/vnd.oasis.opendocument.spreadsheet",
                    "application/vnd.oasis.opendocument.spreadsheet-template",
                    "application/vnd.sun.xml.calc",
                    "application/vnd.sun.xml.calc.template",
                    "application/vnd.stardivision.calc",
                    "application/x-starcalc":
                    return ASSET_IMAGE_FILE_TYPE_SPREADSHEET
                    //PDF
                case "application/vnd.pdf",
                    "application/x-pdf",
                    "application/pdf":
                    return ASSET_IMAGE_FILE_TYPE_PDF
                    //VISIO
                case "application/visio",
                    "application/x-visio",
                    "application/vnd.visio",
                    "application/visio.drawing",
                    "application/vsd",
                    "application/x-vsd",
                    "image/x-vsd",
                    "application/vnd.visio2013",
                    "application/vnd.ms-visio.drawing",
                    "application/vnd.ms-visio.viewer",
                    "application/vnd.ms-visio.stencil",
                    "application/vnd.ms-visio.template":
                    return ASSET_IMAGE_FILE_TYPE_VISIO
                    //Mail
                case "application/x-outlook-msg",
                    "application/vnd.ms-outlook":
                    return ASSET_IMAGE_FILE_TYPE_MAIL
                case "application/vnd.google-apps.document":
                    return ASSET_IMAGE_FILE_TYPE_GOOGLE_DOC
                case "application/vnd.google-apps.presentation":
                    return ASSET_IMAGE_FILE_TYPE_GOOGLE_SLIDE
                case "application/vnd.google-apps.spreadsheet":
                    return ASSET_IMAGE_FILE_TYPE_GOOGLE_SHEET
                default:
                    break
                }
                
                return ASSET_IMAGE_FILE_TYPE_DOCUMENT
            }
            
            
        
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case mimeType = "mime_type"
        case type
     //   case typeId = "type_id"
        case contentSize = "content_size"
        case updateTime = "update_time"
        
       // case url
       // case reserved
        case cmsLinks = "_links"
//        case cmsCategory = "cms_category"
//        case cmsType = "cms_type"
//        case childrenCount = "children_count"
        case parentId = "parent_id"
        case versionNo = "version_no"
//        case originalFileName
//        case typeName = "type_name"
        case owner
//        case caseInstance = "case_instance"
//        case embedded = "_embedded"
//        case properties
//        case traits
//        case modifiedBy = "updated_by"
//        case createdBy =  "created_by"
//        case shortDescription = "description"
//        case reservedUser = "reserved_user_id_expand"
       // case latestVersionNodeId
        //case isEmpty = "is_empty"
    }
    
    //MARK: - initialization
    override init() {
        id = EMPTY_STRING
        name = EMPTY_STRING
        super.init()
    }
    
    init(name:String, contentSize:Int) {
        id = UUID().uuidString
        self.contentSize = contentSize
        self.name = name
    }
    
    init(id: String, name: String, mimeType:String, contentSize: Int, errorMessage: String? = nil) {
        self.id = id
        self.name = name
        self.mimeType = mimeType
        self.contentSize = contentSize
        self.updateTime = EMPTY_STRING
        self.versionNo = 1
       // self.errorMessage = errorMessage
    }
    
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try values.decode(String.self, forKey: .id)
        name = try values.decode(String.self, forKey: .name)
        
//        if let originalFileName = try values.decodeIfPresent(String.self, forKey: .originalFileName) {
//            self.originalFileName = originalFileName
//        } else {
//            self.originalFileName = nil
//        }
        
        if let mimeType = try values.decodeIfPresent(String.self, forKey: .mimeType) {
            self.mimeType = mimeType
        } else {
            self.mimeType = nil
        }
        
        type = try values.decode(String.self, forKey: .type)
        
//        if let typeId = try values.decodeIfPresent(Int.self, forKey: .typeId) {
//            self.typeId = typeId
//        } else {
//            self.typeId = nil
//        }
//
        if let contentSize = try values.decodeIfPresent(Int.self, forKey: .contentSize) {
            self.contentSize = contentSize
        } else {
            self.contentSize = nil
        }
        
        updateTime = try values.decode(String.self, forKey: .updateTime)
        
//        if let url = try values.decodeIfPresent(String.self, forKey: .url) {
//            self.url = url
//        } else {
//            self.url = nil
//        }
        
     //   reserved = try values.decode(Bool.self, forKey: .reserved)
        
        if let cmsLinks = try values.decodeIfPresent(CmsLinks.self, forKey: .cmsLinks) {
            self.cmsLinks = cmsLinks
        } else {
            self.cmsLinks = nil
        }
        
//        if let cmsCategory = try values.decodeIfPresent(String.self, forKey: .cmsCategory) {
//            self.cmsCategory = cmsCategory
//        } else {
//            self.cmsCategory = nil
//        }
//
//        if let cmsType = try values.decodeIfPresent(String.self, forKey: .cmsType) {
//            self.cmsType = cmsType
//        } else {
//            self.cmsType = nil
//        }
        
//        if let childrenCount = try values.decodeIfPresent(Int.self, forKey: .childrenCount) {
//            self.childrenCount = childrenCount
//        } else {
//            self.childrenCount = nil
//        }
//
//        if let isEmpty = try values.decodeIfPresent(Bool.self, forKey: .isEmpty) {
//            self.isEmpty = isEmpty
//        } else {
//            self.isEmpty = nil
//        }
        
        if let parentId = try values.decodeIfPresent(String.self, forKey: .parentId) {
            self.parentId = parentId
        } else {
            self.parentId = nil
        }
        
        if let versionNo = try values.decodeIfPresent(Int.self, forKey: .versionNo) {
            self.versionNo = versionNo
        }
        
//        if let typeName = try? values.decodeIfPresent(String.self, forKey: .typeName) {
//            self.typeName = typeName
//        }
//
        
        //use this
        if let user = try? values.decodeIfPresent(User.self, forKey: .owner) {
            self.owner = user
        }
//
//        if let createdBy = try? values.decodeIfPresent(User.self, forKey: .createdBy) {
//            self.createdBy = createdBy
//        }
//
//        if let modifiedBy = try? values.decodeIfPresent(User.self, forKey: .modifiedBy) {
//            self.modifiedBy = modifiedBy
//        }
//
//
        
        
//        if let properties = try? values.decodeIfPresent(AttributesDataFields.self, forKey: .properties) {
//            self.properties = properties
//        }
        
        
//        if let description = try? values.decodeIfPresent(String.self, forKey: .shortDescription) {
//            self.shortDescription = description
//        }
        
        
//        if let latestVersionNodeId = try? values.decodeIfPresent(String.self, forKey: .latestVersionNodeId) {
//            self.latestVersionNodeId = latestVersionNodeId
//        }
        
    
    }
    
    
    
   
    func ownerID() -> String? {
        return owner?.id
    }
       
    /**
     Time updated formatted for display
     */
    var updateTimeFormatted:String {
        get {
            if let formattedTime = formattedTime {
                return formattedTime
            } else {
                let formatter = DateHelper.ISO8601DateFormatter
                guard let date = formatter.date(from: updateTime) else { return EMPTY_STRING }
                formattedTime = DateHelper.shortDateFormatter.string(from: date)
                return formattedTime ?? ""
            }
        }
    }
    
//    var fileDescription:String? {
//        return shortDescription
//    }
    
    var fileId: String {
        return id
    }
    
//    var fileChildrenCount: Int? {
//        return childrenCount
//    }
    
//    var nodeIsEmpty: Bool? {
//        return isEmpty
//    }
   
    
//    var fileName: String {
//        return originalFileName ?? name
//    }
    
//    var isReserved: Bool {
//        return reserved
//    }
    
//    var contentSizeFormatted: String? {
//        return FileHelper.getFormattedByteInformationFromString(bytesString: contentSize)
//    }
    
//    var fileTypeId: Int? {
//        return typeId
//    }
    
    var fileType: String {
        return type
    }
    
    var fileUniqueKey:String {
        return (parentId ?? "") + name
    }
    
    var fileMimeType: String? {
        return mimeType
    }
    
//    var downloadLink:String? {
//        return originalFileUrl
//    }
    
    var originalFileUrl:String? {
        if let value = self.cmsLinks?.links.filter({$0.key == "urn:eim:linkrel:download-media"}).last?.value {
            //return value.href?.replacingCharacters(in: "https://contentservice-c4sapqe.qe.bp-paas.otxlab.net", with: "cs")
            var finalValue = ""
            if let value = value.href {
                finalValue = value.replacingOccurrences(of: "https://contentservice-c4sapqe.qe.bp-paas.otxlab.net", with: "/cs")
            }
            return finalValue
        }
        return ""
    }
    
//    var isDownloadable:Bool {
//        if  self.nodeActions?.filter({$0.signature == "download"}) != nil, self.cmsLinks?.links.filter({$0.key == "urn:eim:linkrel:download-media"}).last?.value != nil {
//            return true
//        }
//        return false
//    }
    
//    var fileUniqueKey:String {
//        return (parentId ?? "") + name
//    }
    
//    var webUrl:String? {
//        return url
//    }
    
//    var fileParentId:String? {
//        return fileTypeId == NodeTypeID.workspace.rawValue ? caseInstance?.nodeItemParentId ?? parentId : parentId
//    }
    
//    var nodeActions: [NodeActionModel]? {
//        get {
//            return actions
//        }
//
//        set {
//            actions = newValue
//        }
//    }
    
//    var fileCmsType:String? {
//        return cmsType
//    }
//
//    var fileCmsCategory:String? {
//        return cmsCategory
//    }
//
//    var fileTypeName:String? {
//        return typeName
//    }
//
//    var fileCategory:String? {
//        return cmsCategory
//    }
    
//    func updateNodeName(name: String,updateTime: String,description:String?, webAddress:String?) {
//        guard let realm = try? Realm() else { return }
//        try? realm.write {
//            self.name = name
//            self.formattedTime = updateTime
//            self.shortDescription = description
//            // updating url when value is changed from properties
////            if let webAddress {
////                self.url = webAddress
////            }
//        }
//    }
    
//    func updateChildrenCount(increment: Bool) {
//        guard let realm = try? Realm() else { return }
//        try? realm.write {
//            if increment {
//                childrenCount = (childrenCount ?? 0) + 1
//                isEmpty = false
//            } else {
//                if childrenCount ?? 0 > 0 {
//                    childrenCount = (childrenCount ?? 0) - 1
//                    if childrenCount == 0 {
//                        isEmpty = true
//                    }
//                }
//            }
//        }
//    }
    
    
        
    
    
//        func resetChildrenCount() {
//            guard let realm = try? Realm() else { return }
//
//            try? realm.write {
//                childrenCount = 0
//                isEmpty = true
//            }
//        }
//
    
//    func ownerID() -> String? {
//        return owner?.id
//    }
        
   
    
  
    
//    var fileCmsLinks:CmsLinks? {
//        return cmsLinks
//    }
//
    
//    
//    var fileErrorMessage:String? {
//        return errorMessage
//    }
    
//    func deepCopy(with parentID:String) -> FileItemData {
//        let node = NodeModel()
//        node.id = self.id
//        node.name = name
//        node.mimeType = mimeType
//        node.type = type
//        node.typeId = typeId
//        node.contentSize = contentSize
//        node.updateTime = updateTime
//        node.url = url
//        node.reserved = reserved
//        node.cmsLinks = cmsLinks
//        node.cmsCategory = cmsCategory
//        node.cmsType = cmsType
//        node.childrenCount = childrenCount
//        node.parentId = parentID
//        node.versionNo = versionNo
//        node.originalFileName = originalFileName
//        node.shortDescription = shortDescription
//        //used for offline node
//        node.offlineUrl = offlineUrl
//        node.errorMessage = errorMessage
//        node.isPermanentError = isPermanentError
//        node.offlineTimeStamp = offlineTimeStamp
//        node.typeName = typeName
//       
//        return node
//    }
    
    func getUpdatedTime(in dateFromat: DateFormatter) -> String {
        let formatter = DateHelper.ISO8601DateFormatter
        guard let date = formatter.date(from: updateTime) else { return EMPTY_STRING }
        return dateFromat.string(from: date)
    }
    
}
