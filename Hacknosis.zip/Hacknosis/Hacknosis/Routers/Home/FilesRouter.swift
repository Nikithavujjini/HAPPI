//
//  FilesRouter.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import Foundation

enum NodeRouterType {
    ///Get node based on node id
    case getReportsList(rootId:String)
    case uploadFileToCss(name:String, mimeType:String)
    case getNodeDetailsWithBlobId(uploadModel: UploadFileWithPropertiesModel)
    case getMaskedFileFromGCP(bytesData: String)
    case uploadFileToCms(fileName: String, rootFolderId: String,blobIdInitial: String,blodIdMasked: String)
    case getDocumentDownloadUrl(uri: String)
}

/**
 Used for node routes.
 */
class FilesRouter:CoreAbstractRouter {
    var routerType:NodeRouterType
  //  private var sharedLink: LinkShareModel?

    ///This part of the url should just include the host.
    override var hostUrl:URL? {
//        if let sharedLink {
//            return sharedLink.currentEnvironmentUrl
//        }
        guard let hostUrl = EnvironmentManager.shared.cmsUrl else { return nil }
        return hostUrl
    }
    
    var cssHostUrl: URL? {
        guard let hostUrl = EnvironmentManager.shared.cssUrl else { return nil }
        return hostUrl
    }
    
    var gcpHostUrl: URL? {
        guard let hostUrl = EnvironmentManager.shared.gcpUrl else { return nil }
        return hostUrl
    }
    
    override var hostWithPathUrl: URL? {
        guard var apiUrl = hostUrl else { return nil }
        switch routerType {
        case .getReportsList(let rootId):
            apiUrl.appendPathComponent("instances/folder/cms_folder")
            apiUrl.appendPathComponent(rootId)
            apiUrl.appendPathComponent("items")
            return apiUrl
            
            case .uploadFileToCss:
            guard var  apiUrl1 = cssHostUrl else { return nil }
                apiUrl1.appendPathComponent("v2/content")
                return apiUrl1
        case .getNodeDetailsWithBlobId(_):
            apiUrl.appendPathComponent("node")
            return apiUrl
      //  https://cms-c4sapqe.qe.bp-paas.otxlab.net/instances/folder/cms_folder/{{root_id}}/items
        
     
        case .getMaskedFileFromGCP(_):
            guard var apiUrl1 = gcpHostUrl else { return nil }
            apiUrl1.appendPathComponent("v2/projects")
            apiUrl1.appendPathComponent(gcpProjectName)
            apiUrl1.appendPathComponent("image:redact")
            return apiUrl1
        case .uploadFileToCms:
            apiUrl.appendPathComponent("instances/file/def_patient_doc_type")
            return apiUrl
        case .getDocumentDownloadUrl(let uri):
            var hostString = EnvironmentManager.shared.currentEnvironmentUrlWithSubscription?.absoluteString ?? ""
            hostString += uri
            return URL(string: hostString)
        }
    }
    
    override var contentType: HTTPContentType {
        switch routerType {

        case .uploadFileToCss:
            return .multipart
        case .getNodeDetailsWithBlobId, .getMaskedFileFromGCP, .uploadFileToCms:
            return .json
        default: return .any
        }
    }
    
    override var httpMethod: HTTPMethod {
        switch routerType {
        case .getReportsList(_):
            return .get
        case .uploadFileToCss, .getNodeDetailsWithBlobId, .getMaskedFileFromGCP, .uploadFileToCms:
            return .post
        default:
            return .get
        }
    }
    

    
    override var httpBody: Data? {
        switch routerType {
            
        case .getReportsList(_), .uploadFileToCss :
            return nil
        case .getNodeDetailsWithBlobId(let uploadModel):
            var json: [String: Any] = ["crude_op" : "create"]
           // json["cms_category"] = uploadModel.cmsCategory
            json["cms_type"] = uploadModel.cmsType
            json["description"] = uploadModel.description
            json["blob_id"] = uploadModel.blobId
            json["content_size"] = uploadModel.contentSize
            json["mime_type"] = uploadModel.mimeType
            json["name"] = uploadModel.name
            json["parent_id"] = uploadModel.parentId
            json["traits"] = uploadModel.traits
            json["properties"] = uploadModel.properties
            json["version_label"] = uploadModel.versionLabel
            
            if let caseNodeId = uploadModel.caseNodeId {
                json["case_node_id"] = caseNodeId
            }
            
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            return jsonData
        case .getMaskedFileFromGCP(let bytesData):
//            var json: [String: Any] = ["data" : bytesData]
//            json["type"] = "IMAGE"
            var json1: [String: Any] = ["byteItem" : ["data" : bytesData,"type": "IMAGE"]]
            let jsonData = try? JSONSerialization.data(withJSONObject: json1)
            return jsonData
        case .uploadFileToCms(let fileName,let rootFolderId,let blobIdInitial,let blodIdMasked):
            var json: [String: Any] = ["name": fileName]
            json["parent_folder_id"] = rootFolderId
            json["renditions"] = [["blob_id": blobIdInitial,"name":json["name"],"rendition_type":"PRIMARY"], ["blob_id":blodIdMasked,"name":"\(String(describing: json["name"]))  masked","rendition_type":"secondary"]]
            json["properties"] = ["reviewed" : false]
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            return jsonData
        default:
            return nil
        }
    }
    
    override var queryParameters: HTTPParameters {
        switch routerType {
        
        case .getReportsList(_):
//            if sharedLink != nil {
//                return ["include-children-total" : "false"]
//            } else {
                return ["include-children-total" : "false", "fetch-latest" : "true"]
        case .getMaskedFileFromGCP(_):
            
            return ["key" : EnvironmentManager.shared.gcpApiKey]
        default:
            return [:]
           // }
        }
    }
    
//    override var headers: HTTPHeaders {
//        switch routerType {
//
//        case .getMaskedFileFromGCP:
//            return ["x-ios-bundle-identifier" : "com.opentext.e.content.core"]
//        default:
//            return[:]
//        }
//    }
//    init(routerType:NodeRouterType){
//        self.routerType = routerType
//        super.init()
//    }
    
    init(routerType:NodeRouterType){
       // self.sharedLink = sharedLink
        self.routerType = routerType
        super.init()
    }
    
    override var acceptContentType: HTTPContentType? {
        switch routerType {
        case .getReportsList(_), .uploadFileToCss(_, _), .getNodeDetailsWithBlobId(_) :
            return .halJson
        default :
            return .any
        }
    }
        
}


