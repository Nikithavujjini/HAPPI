//
//  FilesScreenView.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 17/10/23.
//

import SwiftUI

struct FilesScreenView: View {
    
    @StateObject var viewModel: FilesViewModel = FilesViewModel()
    @Environment(\.viewController) private var viewControllerHolder: UIViewController?
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                if viewModel.isShowingEmptyList {
                    Text("Add reports for review")
                        
                        .onTapGesture {
                            viewModel.showUploadView = true
                            
                        }
                }
               // ScrollView() {
                    VStack(spacing:0) {
                        ForEach(viewModel.nodes, id: \.fileId) { node in
                            addFilesContent(node: node)
                                .swipeActions(edge: .trailing) {
                                    Button {
                                        //add action
                                    } label: {
                                        Label("Properties", systemImage: "trash")
                                    }
//                                    Button {
//                                      //action
//                                    } label: {
//                                        Label("Share", systemImage: "flag")
//                                    }
                                }
//                                .swipeActions {
//
//                                }
                            Color(COLOR_LIST_DIVIDER)
                                .frame(height:1)
                        }
                    }
               // }
            }
            .onChange(of: viewModel.showUploadView, perform: { value in
                if value {
                    uploadFilesPopup()
                } else {
                    viewControllerHolder?.dismiss(animated: false)
                }
            })
            NavigationLink(EMPTY_STRING, destination: ViewerScreenView(node: viewModel.nodeToViewer,updatedTime: viewModel.nodeToViewer?.updateTime), isActive:$viewModel.isShowingViewer).opacity(0).isHidden(true)
        }
        .uiKitOnAppear {
            viewModel.onViewAppear()
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationTitle("Reports")
        .navigationBarBackButtonHidden(false)
    }
    
    func addFilesContent(node: NodeModel) -> some View {
        return FilesListItemView(node: node)
            
            .onTapGesture(count: 1) {
                viewModel.showViewer(node: node)
            }
    }
    fileprivate func uploadFilesPopup() {
        var uploadOptions = UploadHelper.uploadTypeList
        
        self.viewControllerHolder?.present(backgroundColor:UIColor(red: 0, green: 0, blue: 0, alpha: 0.5),
                                           shouldAnimate: false) {
            UploadFilesView(showUploadView: $viewModel.showUploadView,
                            uploadType:viewModel.uploadType,
                            node: viewModel.selectedNodeForUpload ?? NodeModel(id: "bf415310-f76b-4c8b-a617-b6f21eebe18c", name: "patient_root_folder", mimeType: "", contentSize: 0), uploadHelper: uploadOptions,
                            onSelection: { mediaItems, duplicateFileNames in
                withOutAnimation(execute: {
                    viewModel.showUploadView = false
                }, completion: {
                    if mediaItems.items.count > 0 {
                        viewModel.selectedMediaItems = mediaItems
                        
                        viewModel.uploadSelectedFiles()
                        
                    } else {
                        viewModel.selectedNodeForUpload = nil
                    }
                })
            })
        }
    }
}

struct FilesScreenView_Previews: PreviewProvider {
    static var previews: some View {
        FilesScreenView()
    }
}
