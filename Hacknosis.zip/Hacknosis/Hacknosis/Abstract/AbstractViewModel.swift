//
//  AbstractViewModel.swift
//  Hacknosis
//
//  Created by Vujjini Nikitha on 18/10/23.
//

import Foundation

class AbstractViewModel  {
    @Published var isShowingSheet: Bool = false
    @Published var isLoading: Bool = false
    @Published var showUploadView = false
    @Published var uploadType:UploadType = .camera
    @Published var selectedNode:NodeModel?
    
    @Published var isShowingEmptyList:Bool = false
    
}
